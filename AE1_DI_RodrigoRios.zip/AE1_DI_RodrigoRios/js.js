// Función para mostrar/ocultar secciones, mediante el id, seleccionamos la seccion del html a mostrar.
function mostrarSeccion(id) {
  document.querySelectorAll('main section').forEach(seccion => {
    // El selectorAll selecciona todas las etiquetas section dentro del main
    seccion.classList.add('d-none');
    // Esto es una especie de bucle que va descartando opciones hasta mostrar la correcta.
  });
  document.getElementById(id).classList.remove('d-none');
//   Por último seleccionamos el id correcto.
}
