package paquetes;
import java.util.*;
public class Principal{
    public static void main(String[] args) {
        LinkedList<Notificable> listaNotificaciones = new LinkedList<>();
        listaNotificaciones.add(new NotificacionEmail("hola@campusfp.es"));
        listaNotificaciones.add(new NotificacionSMS("600000000"));
        String mensaje = "Hola desde la clase principal :)";
        for (Notificable notificable : listaNotificaciones) {
            notificable.enviar(mensaje);
        }
    }
}
