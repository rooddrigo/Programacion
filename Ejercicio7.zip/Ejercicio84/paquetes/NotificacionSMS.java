package paquetes;
public class NotificacionSMS implements Notificable {
		private String numeroTelefono;
		 public NotificacionSMS(String numeroTelefono) {
	        this.numeroTelefono = numeroTelefono;
	    }
	    @Override
	    public void enviar(String mensaje) {
	        System.out.println("Mensaje enviado a " + numeroTelefono + ": " + mensaje);
	    }
	}

