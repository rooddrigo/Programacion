package paquetes;
public class NotificacionEmail implements Notificable {
	private String direccionCorreo;
	 public NotificacionEmail(String direccionCorreo) {
        this.direccionCorreo = direccionCorreo;
    }
    @Override
    public void enviar(String mensaje) {
        System.out.println("Correo enviado a " + direccionCorreo + ": " + mensaje);
    }
}

