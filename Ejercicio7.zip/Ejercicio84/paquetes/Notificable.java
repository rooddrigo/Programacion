package paquetes;
public interface Notificable {
	void enviar(String mensaje);
}
