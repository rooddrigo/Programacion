package paquetes;
public interface Calculable {
	double calcularArea();
}
