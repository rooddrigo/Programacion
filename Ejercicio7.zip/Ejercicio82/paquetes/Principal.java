package paquetes;
import java.util.*;
public class Principal {
    public static void main(String[] args) {
        ArrayList<Figura> figuras = new ArrayList<>();
        figuras.add(new Circulo("c1", 2));
        figuras.add(new Rectangulo("r1", 2, 4));
        figuras.add(new Circulo("c2", 33));
        figuras.add(new Rectangulo("r2", 4, 8));
        double areaTotal = 0;
        for (Figura figura : figuras) {
            double area = figura.calcularArea();
            System.out.println("Área de la figura: " + area);
            areaTotal += area;
        }
        System.out.println("Área total del cuadrado y rectangulo: " + areaTotal);
    }
}