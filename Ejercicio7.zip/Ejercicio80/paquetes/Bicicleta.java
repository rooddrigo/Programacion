package paquetes;
public class Bicicleta extends Vehiculo implements Movible {
    public Bicicleta(String id) {
        super(id);
    }
    @Override
    public void mover() {
        System.out.println("Bicicleta " + id + " pedale por el carril bici.");
    }
}
