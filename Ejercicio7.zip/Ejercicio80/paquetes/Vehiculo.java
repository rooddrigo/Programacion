package paquetes;
public abstract class Vehiculo {
	protected String id;
	public Vehiculo(String id) {
		this.id = id;
	}
}
