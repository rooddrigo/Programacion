package paquetes;
import java.util.*;
public class Principal {
    public static void main(String[] args) {
        ArrayList<Movible> vehiculos = new ArrayList<>();
        vehiculos.add(new Coche("c1"));
        vehiculos.add(new Bicicleta("b1"));
        vehiculos.add(new Coche("C2"));
        vehiculos.add(new Bicicleta("B2"));
        for (Movible vehiculo : vehiculos) {
            vehiculo.mover();
        }
    }
}
