package paquetes;
public interface Movible {
	public void mover();
}
