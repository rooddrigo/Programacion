package paquetes;
public interface Describible {
	String describir();
}
