package paquetes;
public abstract class Item implements Describible {
    protected int id;
    public Item(int id) {
        this.id = id;
    }
}