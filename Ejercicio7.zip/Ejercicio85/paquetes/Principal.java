package paquetes;
import java.util.*;
public class Principal {
    public static void main(String[] args) {
        HashMap<String, ArrayList<Item>> inventario = new HashMap<>();
        inventario.put("Libros", new ArrayList<>());
        inventario.put("Electrónicos", new ArrayList<>());
        inventario.get("Libros").add(new Libro(1, "Entiende la tecnologia"));
        inventario.get("Libros").add(new Libro(2, "Star Wars"));
        inventario.get("Electrónicos").add(new Electronico(-1, "Samsung"));
        inventario.get("Electrónicos").add(new Electronico(-2, "Iphone"));
        for (Map.Entry<String, ArrayList<Item>> entry : inventario.entrySet()) {
            System.out.println("Categoría: " + entry.getKey());
            for (Item item : entry.getValue()) {
                System.out.println(" - " + item.describir());
            }
        }
    }
}