package paquetes;
import java.util.*;

public class HashmapColores {
    public static void main(String[] args) {
    	  HashSet<String> colores = new HashSet<>();
          colores.add("Rojo");
          colores.add("Azul");
          colores.add("Verde");
          colores.add("Rojo"); 
          colores.add("Azul");
          System.out.println("Colores únicos: " + colores.size());
}
}