package paquetes;
import java.util.Scanner;
public class ArrayEnteros {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] numeros = new int[5]; 
        System.out.println("Introduce 5 numeros ");
        for (int i = 0; i < numeros.length; i++) {
            System.out.print("Numero: ");
            numeros[i] = scanner.nextInt();
        }
        System.out.println("Los numeros introducidos son:");
        for (int num : numeros) {
            System.out.println(num);
        }
        scanner.close();
    }
}
