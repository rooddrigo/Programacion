package paquetes;
public interface Medible {
	 double leerValor();
	 String getUnidad();
}
