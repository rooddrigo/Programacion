package paquetes;
import java.util.*;
public class Principal {
    public static void main(String[] args) {
        ArrayList<Sensor> sensores = new ArrayList<>();
        sensores.add(new SensorTemperatura("temp1", "Aula 10"));
        sensores.add(new SensorHumedad("hum1", "Taller"));
        sensores.add(new SensorTemperatura("temp2", "Aula 11"));
        sensores.add(new SensorHumedad("hum2", "Cafeteria"));
        HashMap<String, Double> lecturas = new HashMap<>();
        for (Sensor sensor : sensores) {
            double valor = sensor.leerValor();
            String unidad = sensor.getUnidad();
            System.out.println("Sensor " + sensor.getId() + " en " + sensor.ubicacion + " = " + valor + " " + unidad);
            lecturas.put(sensor.getId(), valor);
        }
    }
}
