package paquetes;
public class SensorHumedad extends Sensor {
    public SensorHumedad(String id, String ubicacion) {
        super(id, ubicacion);
    }
    @Override
    public double leerValor() {
        return 33; 
    }
    @Override
    public String getUnidad() {
        return "%";
    }
}