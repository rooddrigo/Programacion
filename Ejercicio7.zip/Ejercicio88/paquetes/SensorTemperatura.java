package paquetes;
public class SensorTemperatura extends Sensor {
    public SensorTemperatura(String id, String ubicacion) {
        super(id, ubicacion);
    }
    @Override
    public double leerValor() {
        return 33;
    }
    @Override
    public String getUnidad() {
        return "°C";
    }
}