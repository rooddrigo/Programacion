package paquetes;
import java.util.*;
public class Nombres {

	public static void main(String[] args) {
		List<String> nombres = Arrays.asList("Pepe", "Botella", "Miguel");
        for (String n : nombres) {
            System.out.println(n.toUpperCase());
        }
	}
}
