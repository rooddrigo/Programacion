package paquetes;
public interface Pagable {
	double calcularSalarioMensual();
}
