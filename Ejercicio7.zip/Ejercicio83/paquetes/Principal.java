package paquetes;
import java.util.*;
public class Principal {
    public static void main(String[] args) {
        HashMap<Integer, Empleado> empleados = new HashMap<>();
        empleados.put(1, new EmpleadoFijo(1, "Rodrigo", 2000));
        empleados.put(2, new EmpleadoPorHoras(2, "Cesar", 100, 25));
        empleados.put(3, new EmpleadoPorHoras(3, "Isidro", 90, 10));
        empleados.put(4, new EmpleadoFijo(4, "Clemente", 2100));
        for (Map.Entry<Integer, Empleado> entry : empleados.entrySet()) {
            Empleado empleado = entry.getValue();
            System.out.println("Nombre: " + empleado.getNombre() + ": Salario: " + empleado.calcularSalarioMensual());
        }
    }
}
