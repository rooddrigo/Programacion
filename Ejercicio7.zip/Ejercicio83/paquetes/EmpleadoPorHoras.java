package paquetes;
public class EmpleadoPorHoras extends Empleado {
    private int horasTrabajadas;
    private double tarifaHora;
    public EmpleadoPorHoras(int id, String nombre, int horasTrabajadas, double tarifaHora) {
        super(id, nombre);
        this.horasTrabajadas = horasTrabajadas;
        this.tarifaHora = tarifaHora;
    }
    @Override
    public double calcularSalarioMensual() {
        return horasTrabajadas * tarifaHora;
    }
}