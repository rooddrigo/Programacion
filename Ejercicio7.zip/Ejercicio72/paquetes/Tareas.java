package paquetes;

import java.util.ArrayList;
public class Tareas {
	public static void main (String[] args) {
		ArrayList<String> tareas = new ArrayList<>();
		tareas.add("Estudiar");
		tareas.add("Comer");
		tareas.add("Dormir");
	
		tareas.remove("Estudiar"); 
		System.out.println(tareas);	
	}
}
