package paquetes;
class Producto {
    String nombre;
    double precio;
    Producto(String nombre, double precio) {
        this.nombre = nombre;
        this.precio = precio;
    }
}

