package paquetes;
import java.util.*;
public class Principal {
	public static void main(String[] args) {
        List<Producto> productos = Arrays.asList(
            new Producto("Zapas", 800),
            new Producto("Chatgpt Premium", 20),
            new Producto("Hola", 60),
            new Producto("Ropa", 150)
        );

        System.out.println("Productos con precio > 50:");
        for (Producto p : productos) {
            if (p.precio > 50) {
                System.out.println(p.nombre);
            }
        }
    }
}

