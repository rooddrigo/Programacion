package paquetes;
import java.util.*;
public class Hashmap {
    public static void main(String[] args) {
        HashMap<String, Integer> personas = new HashMap<>();
        personas.put("Rodrigo", 18);
        personas.put("Cesar", 20);
        personas.put("Juan", 13);

        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese un nombre para consultar su edad: ");
        String nombre = scanner.nextLine();
        if (personas.containsKey(nombre)) {
            System.out.println("La edad de " + nombre + " es: " + personas.get(nombre));
        }
        scanner.close();
    }
}
