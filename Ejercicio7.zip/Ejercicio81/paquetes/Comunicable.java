package paquetes;
public interface Comunicable {
	String hacerSonido();
}
