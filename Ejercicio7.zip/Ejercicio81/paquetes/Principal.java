package paquetes;
import java.util.*;
public class Principal {
    public static void main(String[] args) {
        ArrayList<Animal> animales = new ArrayList<>();
        animales.add(new Perro("Tobias"));
        animales.add(new Gato("Bigotes"));
        animales.add(new Perro("Kira"));
        animales.add(new Gato("Michi"));
        for (Animal animal : animales) {
            System.out.println(animal.nombre + " hace " + animal.hacerSonido());
        }
    }
}