package paquetes;
public abstract class Cuenta implements Auditable {
    protected String numeroCuenta;
    protected double saldo;
    public Cuenta(String numeroCuenta, double saldo) {
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldo;
    }
}