package paquetes;
public class CuentaCorriente extends Cuenta {
    private double limiteSobregiro;
    public CuentaCorriente(String numeroCuenta, double saldo, double limiteSobregiro) {
        super(numeroCuenta, saldo);
        this.limiteSobregiro = limiteSobregiro;
    }
    @Override
    public String obtenerDetalles() {
        return "Cuenta Corriente: " + numeroCuenta + "|| Saldo: " + saldo + "|| Límite de sobregiro: " + limiteSobregiro;
    }
}
