package paquetes;
public interface Auditable {
	String obtenerDetalles();
}
