package paquetes;
public class CuentaAhorro extends Cuenta {
    private double tasaInteres;
    public CuentaAhorro(String numeroCuenta, double saldo, double tasaInteres) {
        super(numeroCuenta, saldo);
        this.tasaInteres = tasaInteres;
    }
    @Override
    public String obtenerDetalles() {
        return "Cuenta Ahorro: " + numeroCuenta + "|| Saldo: " + saldo + "|| Tasa de interés: " + tasaInteres + "%";
    }
}