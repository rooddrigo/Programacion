package paquetes;
import java.util.*;
public class Principal {
    public static void main(String[] args) {
        HashMap<String, Cuenta> cuentas = new HashMap<>();
        cuentas.put("1001", new CuentaAhorro("A01", 1000, 8));
        cuentas.put("2001", new CuentaCorriente("C01", 1500, 100));
        cuentas.put("1002", new CuentaAhorro("A02", 2000, 2));
        cuentas.put("2002", new CuentaCorriente("C02", 2500, 200));
        for (Cuenta cuenta : cuentas.values()) {
            System.out.println(cuenta.obtenerDetalles());
        }
    }
}
