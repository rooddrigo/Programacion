package paquetes;
import java.util.*;
public class NumerosOrdenados {
    public static void main(String[] args) {
	List<Integer> numeros = Arrays.asList(5,4,3,2,1,0);
    Collections.sort(numeros);
    System.out.println("Números ordenados: " + numeros);

}
}
