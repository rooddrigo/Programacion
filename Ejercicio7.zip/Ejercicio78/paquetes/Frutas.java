package paquetes;
import java.util.*;
public class Frutas {
    public static void main(String[] args) {
        List<String> frutas = new ArrayList<>(Arrays.asList("Piña", "Melocoton", "Pepe", "Naranja"));
        Iterator<String> it = frutas.iterator();
        while (it.hasNext()) {
            String fruta = it.next();
            if (fruta.equals("Pepe")) {
                it.remove();
            }
        }
        System.out.println("Lista de frutas: " + frutas);
    }
}
