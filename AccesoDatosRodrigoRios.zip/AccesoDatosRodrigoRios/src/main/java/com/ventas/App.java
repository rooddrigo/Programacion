package com.ventas;

import model.Venta;
import com.ventas.service.VentaService;
import com.ventas.service.ExportadorService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import java.util.List;

public class App {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

        VentaService ventaService = context.getBean(VentaService.class);
        ExportadorService exportadorService = context.getBean(ExportadorService.class);

        System.out.println("Todas las ventas:");
        List<Venta> ventas = ventaService.listarVentas();
        ventas.forEach(System.out::println);

        Venta nuevaVenta = new Venta(15, "Bufanda verde", 2, 15.0);
        ventaService.insertarVenta(nuevaVenta);
        System.out.println("\nVenta insertada: " + nuevaVenta);

        System.out.println("\nVentas de 'Zapatillas negras':");
        List<Venta> filtradas = ventaService.listarPorProducto("Zapatillas negras");
        filtradas.forEach(System.out::println);

        exportadorService.exportar();
    }
}
