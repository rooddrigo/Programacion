package com.ventas.service;
import model.Venta;
import org.springframework.stereotype.Service;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

@Service
public class ExportadorService {

    private final VentaService ventaService;

    public ExportadorService(VentaService ventaService) {
        this.ventaService = ventaService;
    }

    public void exportar() {
        List<Venta> ventas = ventaService.listarVentas();
        double totalGeneral = 0;

        try (FileWriter fw = new FileWriter("Ventas.txt")) {
            for (Venta v : ventas) {
                double totalVenta = v.getCantidad() * v.getPrecio();
                fw.write(v.toString() + ", Total: " + totalVenta + "\n");
                totalGeneral += totalVenta;
            }
            fw.write("\nRecaudación total: " + totalGeneral);
            System.out.println("Ventas exportadas correctamente a Ventas.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
