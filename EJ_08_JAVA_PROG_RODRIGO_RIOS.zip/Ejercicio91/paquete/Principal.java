package paquete;
import java.io.*;
import java.util.*;

public class Principal {
    public static void main(String[] args) {

    	Scanner scanner = new Scanner(System.in);
        System.out.print("Introduce la frase que te apetezca: ");
        String frase = scanner.nextLine();
        try (BufferedWriter texto = new BufferedWriter(new FileWriter("mensaje.txt"))) {
            texto.write(frase);
            texto.newLine();
            System.out.println("Frase escrita en el archivo.");
        } catch (IOException e) {
            System.out.println("Error al escribir en el archivo: " + e.getMessage());
        }
        System.out.println("\nContenido:");
        try (BufferedReader reader = new BufferedReader(new FileReader("mensaje.txt"))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                System.out.println(linea);
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
        scanner.close();
    }
}