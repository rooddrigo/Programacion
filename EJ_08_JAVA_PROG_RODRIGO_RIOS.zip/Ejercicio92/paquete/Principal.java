package paquete;

import java.io.*;
public class Principal {
    public static void main(String[] args) {
        Animal a1 = new Animal("isidro", "caballo");
        try {
            ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("animal.ser"));
            out.writeObject(a1);
            out.close();
            System.out.println("Objeto Animal guardado correctamente.");
        } catch (IOException e) {
            System.out.println("Error guardando el objeto: " + e.getMessage());
        }
        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream("animal.ser"));
            Animal animalRecuperado = (Animal) in.readObject();
            in.close();
            System.out.println("Datos del animal recuperado:");
            System.out.println("Nombre: " + animalRecuperado.nombre);
            System.out.println("Especie: " + animalRecuperado.especie);
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error leyendo el objeto: " + e.getMessage());
        }
    }
}