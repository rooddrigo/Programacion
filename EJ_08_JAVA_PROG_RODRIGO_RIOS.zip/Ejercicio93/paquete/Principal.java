package paquete;
import java.io.*;
public class Principal {
	    public static void main(String[] args) {
	    	  int sumaTotal = 0;
	          try {
	              BufferedReader lector = new BufferedReader(new FileReader("numeros.txt"));
	              String linea;

	              while ((linea = lector.readLine()) != null) {
	                  try {
	                      int numero = Integer.parseInt(linea.trim());
	                      sumaTotal += numero;
	                  } catch (NumberFormatException e) {
	                      System.out.println("Línea inválida: " + linea);
	                  }
	              }
	              lector.close();
	              System.out.println("Suma total de los números: " + sumaTotal);
	          } catch (FileNotFoundException e) {
	              System.out.println("El archivo numeros.txt no se encontró.");
	          } catch (IOException e) {
	              System.out.println("Error leyendo el archivo: " + e.getMessage());
	          }
	      }
}
