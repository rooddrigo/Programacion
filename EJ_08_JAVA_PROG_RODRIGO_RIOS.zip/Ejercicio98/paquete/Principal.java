package paquete;
import java.io.*;
import java.util.Scanner;
public class Principal{
    static final String CARPETA = "notas";
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        File dir = new File(CARPETA);
        if (!dir.exists()) dir.mkdir(); 

        while (true) {
            System.out.println("\n1. Crear nota\n2. Leer todas las notas\n3. Eliminar nota\n4. Salir");
            System.out.print("Opción: ");
            String opcion = sc.nextLine();
            if (opcion.equals("1")) {
                try {
                    System.out.print("Título (sin espacios): ");
                    String titulo = sc.nextLine();
                    System.out.println("Contenido:");
                    String contenido = sc.nextLine();

                    Nota nota = new Nota(titulo, contenido);
                    FileWriter fw = new FileWriter(CARPETA + "/" + titulo + ".txt");
                    fw.write(nota.contenido);
                    fw.close();
                    System.out.println("Nota guardada.");
                } catch (IOException e) {
                    System.out.println("Error al guardar la nota: " + e.getMessage());
                }
            } else if (opcion.equals("2")) {
                File[] archivos = dir.listFiles();
                if (archivos == null || archivos.length == 0) {
                    System.out.println("No hay notas guardadas.");
                } else {
                    System.out.println("\n--- Notas guardadas ---");
                    for (File archivo : archivos) {
                        System.out.println("Título: " + archivo.getName().replace(".txt", ""));
                        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
                            String linea;
                            while ((linea = br.readLine()) != null) {
                                System.out.println(linea);
                            }
                        } catch (IOException e) {
                            System.out.println("Error al leer " + archivo.getName());
                        }
                    }
                }
            } else if (opcion.equals("3")) {
                System.out.print("Nombre de la nota a eliminar (sin .txt): ");
                String nombre = sc.nextLine();
                File f = new File(CARPETA + "/" + nombre + ".txt");
                if (f.exists()) {
                    if (f.delete()) {
                        System.out.println("Nota eliminada.");
                    } else {
                        System.out.println("No se pudo eliminar la nota.");
                    }
                } else {
                    System.out.println("La nota no existe.");
                }
            } else if (opcion.equals("4")) {
                break;
            } else {
                System.out.println("Opción no válida.");
            }
        }
    }
}

