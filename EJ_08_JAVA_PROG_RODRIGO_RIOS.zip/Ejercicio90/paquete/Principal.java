package paquete;
import java.util.*;
public class Principal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.println("Introduce el primer número: ");
            int a = sc.nextInt();
            System.out.println("Introduce el segundo número: ");
            int b = sc.nextInt();
            int resultado = a / b;
            System.out.println("Resultado: " + resultado);
        } catch (ArithmeticException e) {
            System.out.println("Error: No se puede dividir entre cero.");
        } catch (InputMismatchException e) {
            System.out.println("Error: Entrada no válida. Debes introducir un número entero.");
        } finally {
            sc.close();
            System.out.println("Programa finalizado.");
        }
    }
}