package paquete;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
	public class Principal {
	    public static void main(String[] args) {
	        try {
	            FileWriter fw = new FileWriter("historial.txt", true); // true = modo append
	            LocalDateTime ahora = LocalDateTime.now();
	            DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	            fw.write(ahora.format(formato) + "\n");
	            fw.close();
	            System.out.println("Hora y fecha añadida.");
	        } catch (IOException e) {
	            System.out.println("Error al escribir en el archivo: " + e.getMessage());
	        }
	    }
	}
