package paquete;
import java.io.*;
import java.util.Scanner;
public class Principal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce el nombre del archivo: ");
        String nombreArchivo = sc.nextLine();

        try {
            BufferedReader lector = new BufferedReader(new FileReader(nombreArchivo));
            System.out.println("Contenido: ");
            String linea;
            while ((linea = lector.readLine()) != null) {
                System.out.println(linea);
            }

            lector.close();
        } catch (FileNotFoundException e) {
            System.out.println("El archivo \"" + nombreArchivo + "\" no existe.");
        } catch (IOException e) {
            System.out.println("Error leyendo el archivo: " + e.getMessage());
        }
        sc.close();
    }

}
