package paquete;
import java.io.*;
import java.util.*;
public class Principal {
    static final String ARCHIVO = "empleados.dat";
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n1. Añadir empleado\n2. Mostrar empleados\n3. Salir");
            System.out.print("Opción: ");
            String opcion = sc.nextLine();

            if (opcion.equals("1")) {
                try {
                    System.out.print("Nombre: ");
                    String nombre = sc.nextLine();
                    System.out.print("Edad: ");
                    int edad = Integer.parseInt(sc.nextLine());
                    System.out.print("Salario: ");
                    double salario = Double.parseDouble(sc.nextLine());
                    Empleado emp = new Empleado(nombre, edad, salario);
                    ArrayList<Empleado> lista = leer();
                    lista.add(emp);
                    guardar(lista);
                    System.out.println("Empleado añadido.");
                } catch (Exception e) {
                    System.out.println("Error: " + e.getMessage());
                }
            } else if (opcion.equals("2")) {
                try {
                    ArrayList<Empleado> lista = leer();
                    if (lista.isEmpty()) {
                        System.out.println("No hay empleados.");
                    } else {
                        for (Empleado e : lista) {
                            System.out.println(e);
                        }
                    }
                } catch (Exception e) {
                    System.out.println("Error al leer empleados.");
                }
            } else if (opcion.equals("3")) {
                break;
            } else {
                System.out.println("Opción no válida.");
            }
        }
    }
    static void guardar(ArrayList<Empleado> lista) throws IOException {
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(ARCHIVO));
        out.writeObject(lista);
        out.close();
    }
    static ArrayList<Empleado> leer() {
        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream(ARCHIVO));
            ArrayList<Empleado> lista = (ArrayList<Empleado>) in.readObject();
            in.close();
            return lista;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }
}
