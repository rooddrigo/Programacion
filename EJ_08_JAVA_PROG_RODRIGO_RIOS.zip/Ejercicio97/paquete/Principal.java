package paquete;

import java.io.*;
import java.util.*;
public class Principal {
    static final String ARCHIVO = "productos.dat";
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n1. Añadir producto\n2. Mostrar productos\n3. Salir");
            System.out.print("Opción: ");
            String opcion = sc.nextLine();

            if (opcion.equals("1")) {
                try {
                    System.out.print("Nombre: ");
                    String nombre = sc.nextLine();
                    System.out.print("Precio: ");
                    double precio = Double.parseDouble(sc.nextLine());
                    System.out.print("Categoría: ");
                    String categoria = sc.nextLine();

                    Producto p = new Producto(nombre, precio, categoria);
                    ArrayList<Producto> lista = leer();
                    lista.add(p);
                    guardar(lista);
                    System.out.println("Producto añadido.");
                } catch (Exception e) {
                    System.out.println("Error: " + e.getMessage());
                }

            } else if (opcion.equals("2")) {
                ArrayList<Producto> lista = leer();
                if (lista.isEmpty()) {
                    System.out.println("No hay productos.");
                } else {
                    for (Producto p : lista) {
                        System.out.println(p);
                    }
                }

            } else if (opcion.equals("3")) {
                break;

            } else {
                System.out.println("Opción no válida.");
            }
        }
    }
    static void guardar(ArrayList<Producto> lista) {
        try {
            ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(ARCHIVO));
            out.writeObject(lista);
            out.close();
        } catch (IOException e) {
            System.out.println("Error al guardar: " + e.getMessage());
        }
    }
    static ArrayList<Producto> leer() {
        File f = new File(ARCHIVO);
        if (!f.exists()) {
            return new ArrayList<>();
        }
        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream(ARCHIVO));
            ArrayList<Producto> lista = (ArrayList<Producto>) in.readObject();
            in.close();
            return lista;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }
}
