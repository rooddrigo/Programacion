package paquete;
import java.io.*;
public class Producto implements Serializable {
    String nombre;
    double precio;
    String categoria;
    public Producto(String nombre, double precio, String categoria) {
        this.nombre = nombre;
        this.precio = precio;
        this.categoria = categoria;
    }
    public String toString() {
        return "Nombre: " + nombre + ", Precio: " + precio + ", Categoría: " + categoria;
    }
}
