package paquete;
import java.io.*;
import java.util.*;

public class Principal {
    static final String ARCHIVO = "usuarios.txt";
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n1. Registrarse\n2. Iniciar sesión\n3. Salir");
            System.out.print("Opción: ");
            String opcion = sc.nextLine();

            if (opcion.equals("1")) {
                registrar(sc);
            } else if (opcion.equals("2")) {
                login(sc);
            } else if (opcion.equals("3")) {
                break;
            } else {
                System.out.println("Opción no válida.");
            }
        }
    }
    static void registrar(Scanner sc) {
        try {
            System.out.print("Nombre de usuario: ");
            String usuario = sc.nextLine();
            System.out.print("Contraseña: ");
            String pass = sc.nextLine();

            // Verificar si el usuario ya existe
            if (existeUsuario(usuario)) {
                System.out.println("Ese nombre de usuario ya está registrado.");
                return;
            }

            FileWriter fw = new FileWriter(ARCHIVO, true);
            fw.write(usuario + ":" + pass + "\n");
            fw.close();
            System.out.println("Usuario registrado con éxito.");
        } catch (IOException e) {
            System.out.println("Error al registrar usuario: " + e.getMessage());
        }
    }
    static void login(Scanner sc) {
        try {
            System.out.print("Usuario: ");
            String usuario = sc.nextLine();
            System.out.print("Contraseña: ");
            String pass = sc.nextLine();
            BufferedReader br = new BufferedReader(new FileReader(ARCHIVO));
            String linea;
            boolean encontrado = false;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(":");
                if (partes.length == 2 && partes[0].equals(usuario) && partes[1].equals(pass)) {
                    encontrado = true;
                    break;
                }
            }
            br.close();
            if (encontrado) {
                System.out.println("Inicio de sesión exitoso. ¡Bienvenido, " + usuario + "!");
            } else {
                System.out.println("Usuario o contraseña incorrectos.");
            }
        } catch (FileNotFoundException e) {
            System.out.println("Aún no hay usuarios registrados.");
        } catch (IOException e) {
            System.out.println("Error al leer el archivo de usuarios.");
        }
    }
    static boolean existeUsuario(String usuario) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(ARCHIVO));
            String linea;
            while ((linea = br.readLine()) != null) {
                if (linea.startsWith(usuario + ":")) {
                    br.close();
                    return true;
                }
            }
            br.close();
        } catch (IOException e) {
        }
        return false;
    }
}

