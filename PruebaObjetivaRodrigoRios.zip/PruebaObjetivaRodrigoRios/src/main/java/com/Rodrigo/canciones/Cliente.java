package com.Rodrigo.canciones;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Scanner;

public class Cliente {
    private static ObjectInputStream entrada;
    private static ObjectOutputStream salida;

    public static void main(String[] args) {
        System.out.println("APLICACIÓN CLIENTE");
        System.out.println("-----------------------------------");

        Scanner lector = new Scanner(System.in);

        try {
            Socket cliente = new Socket();
            InetSocketAddress direccionServidor = new InetSocketAddress("127.0.0.1", 2000);
            System.out.println("Esperando a que el servidor acepte la conexión...");
            cliente.connect(direccionServidor);
            System.out.println("Comunicación establecida con el servidor");

            Thread.sleep(100); // espera corta para evitar problemas de sincronización con los flujos

            salida = new ObjectOutputStream(cliente.getOutputStream()); //  creación de flujos en el mismo orden que servidor
            entrada = new ObjectInputStream(cliente.getInputStream());  //  creación de flujos en el mismo orden que servidor

            String opcion = "";

            do {
                System.out.println("\n--- MENÚ ---");
                System.out.println("1. Una sola canción");
                System.out.println("2. Canciones de un grupo");
                System.out.println("3. Canciones por título");
                System.out.println("4. Todas las canciones de la lista");
                System.out.println("5. Desconectar");
                System.out.print("Selecciona una opción: ");
                System.out.flush(); //  fuerza que el menú se muestre inmediatamente ya que me daba error y no me mostraba

                opcion = lector.nextLine();

                switch (opcion.trim()) {
                    case "1":
                        salida.writeObject("1");
                        salida.flush();
                        String cancion = (String) entrada.readObject(); //  recibimos String en vez de Cancion
                        System.out.println("Canción recibida: " + cancion);
                        break;

                    case "2":
                        salida.writeObject("2");
                        System.out.print("Introduce el nombre del grupo: ");
                        System.out.flush();
                        String grupo = lector.nextLine();
                        salida.writeObject(grupo);
                        salida.flush();
                        ArrayList<String> cancionesGrupo = (ArrayList<String>) entrada.readObject(); //  recibimos lista de Strings
                        System.out.println("Canciones del grupo " + grupo + ":");
                        for (String c : cancionesGrupo) {
                            System.out.println(c);
                        }
                        break;

                    case "3":
                        salida.writeObject("3");
                        System.out.print("Introduce el texto del título: ");
                        System.out.flush();
                        String titulo = lector.nextLine();
                        salida.writeObject(titulo);
                        salida.flush();
                        ArrayList<String> cancionesTitulo = (ArrayList<String>) entrada.readObject(); //  recibimos lista de Strings
                        System.out.println("Canciones que contienen '" + titulo + "':");
                        for (String c : cancionesTitulo) {
                            System.out.println(c);
                        }
                        break;

                    case "4":
                        salida.writeObject("4");
                        salida.flush();
                        ArrayList<String> todas = (ArrayList<String>) entrada.readObject(); //  recibimos lista de Strings
                        System.out.println("Lista completa de canciones:");
                        for (String c : todas) {
                            System.out.println(c);
                        }
                        break;

                    case "5":
                        salida.writeObject("FIN");
                        salida.flush();
                        String mensaje = (String) entrada.readObject(); // recibimos mensaje final
                        System.out.println(mensaje);
                        break;

                    default:
                        System.out.println("Opción no reconocida");
                }

            } while (!opcion.equals("5"));

            entrada.close();
            salida.close();
            cliente.close();
            System.out.println("Comunicación cerrada");

        } catch (UnknownHostException e) {
            System.out.println("No se puede establecer comunicación con el servidor");
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println("Error de E/S");
            System.out.println(e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("Error al recibir datos del servidor: " + e.getMessage());
        } catch (InterruptedException e) {
            System.out.println("Error de sincronización: " + e.getMessage());
        } finally {
            lector.close();
        }
    }
}
