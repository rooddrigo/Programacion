package com.Rodrigo.canciones;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;

public class HiloEscuchador extends Thread {
    private Socket cliente;
    private Canciones canciones;
    private ObjectInputStream entrada;
    private ObjectOutputStream salida;

    public HiloEscuchador(Socket cliente, Canciones canciones) {
        this.cliente = cliente;
        this.canciones = canciones;
    }

    @Override
    public void run() {
        try {
            salida = new ObjectOutputStream(cliente.getOutputStream()); //  salida primero
            entrada = new ObjectInputStream(cliente.getInputStream());   //  entrada después

            String peticion;

            do {
                peticion = (String) entrada.readObject();

                switch (peticion.trim()) {
                    case "1": // Una sola canción
                        salida.writeObject(canciones.cancionAzar().toString()); // enviamos String
                        salida.flush();
                        break;

                    case "2": // Canciones de un grupo
                        String grupo = (String) entrada.readObject();
                        ArrayList<String> listaGrupo = new ArrayList<>();
                        for (Cancion c : canciones.getCancionesGrupo(grupo)) {
                            listaGrupo.add(c.toString()); //  convertimos a String
                        }
                        salida.writeObject(listaGrupo); // enviamos lista de Strings
                        salida.flush();
                        break;

                    case "3": // Canciones por título
                        String titulo = (String) entrada.readObject();
                        ArrayList<String> listaTitulo = new ArrayList<>();
                        for (Cancion c : canciones.getCancionesTitulo(titulo)) {
                            listaTitulo.add(c.toString()); //  convertimos a String
                        }
                        salida.writeObject(listaTitulo); // enviamos lista de Strings
                        salida.flush();
                        break;

                    case "4": // Todas las canciones
                        ArrayList<String> todas = new ArrayList<>();
                        for (Cancion c : canciones.getListaDistribucion()) {
                            todas.add(c.toString()); //convertimos a String
                        }
                        salida.writeObject(todas); // enviamos lista de Strings
                        salida.flush();
                        break;

                    case "5": // Desconectar
                    case "FIN":
                        salida.writeObject("Hasta pronto, gracias por establecer conexión"); //  mensaje final como String
                        salida.flush();
                        break;

                    default:
                        salida.writeObject("Opción no reconocida"); //  mensaje de error
                        salida.flush();
                }

            } while (!peticion.trim().equals("FIN"));

            entrada.close();
            salida.close();
            cliente.close();

        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error en la comunicación con el cliente: " + e.getMessage());
        }
    }
}
