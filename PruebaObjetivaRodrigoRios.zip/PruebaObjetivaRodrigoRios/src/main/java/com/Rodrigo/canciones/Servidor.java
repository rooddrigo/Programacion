package com.Rodrigo.canciones;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {
    public static void main(String[] args) {
        Canciones canciones = new Canciones(); // Lista compartida entre todos los hilos
        System.out.println("APLICACIÓN DE SERVIDOR PROVEEDORA DE CANCIONES");
        System.out.println("-------------------------------------------------");

        try {
            ServerSocket servidor = new ServerSocket();
            InetSocketAddress direccion = new InetSocketAddress("127.0.0.1", 2000);
            servidor.bind(direccion);
            System.out.println("Servidor escuchando en IP: " + direccion.getAddress() + ", puerto: " + direccion.getPort());

            // Bucle infinito para aceptar múltiples clientes
            while (true) {
                Socket enchufeAlCliente = servidor.accept(); // Esperamos conexión de un cliente
                System.out.println("Cliente conectado desde: " + enchufeAlCliente.getInetAddress());

                // Lanzamos un nuevo hilo HiloEscuchador para atender al cliente
                HiloEscuchador hilo = new HiloEscuchador(enchufeAlCliente, canciones);
                hilo.start();
            }

        } catch (IOException e) {
            System.out.println("Error en el servidor: " + e.getMessage());
        }
    }
}
