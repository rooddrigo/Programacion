package utilidades;

import static utilidades.Mensaje.imprimirMensaje;

public class Principal {
    public static void main(String[] args) {
        imprimirMensaje();
    }
}
