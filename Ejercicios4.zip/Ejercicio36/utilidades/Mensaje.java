package utilidades;

public class Mensaje {
	public static void imprimirMensaje() {
		System.out.println("¡Hola desde mis utilidades!");
	}
}
