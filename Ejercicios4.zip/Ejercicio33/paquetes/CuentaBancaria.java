package paquetes;

public class CuentaBancaria {
    private double saldo;

    public double depositar(double cantidad) {
        saldo += cantidad;
        return saldo; 
    }
    public double retirar(double cantidad) {
        saldo -= cantidad;
        return saldo; 
    }
    public double getSaldo() {
        return saldo;
    }
}
