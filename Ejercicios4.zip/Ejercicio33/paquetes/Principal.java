package paquetes;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CuentaBancaria cuenta = new CuentaBancaria();
		System.out.println("Saldo a depositar: " + cuenta.depositar(1000));
		System.out.println("Saldo a retirar: " + cuenta.retirar(500));
		System.out.println("Saldo final de la cuenta: " + cuenta.getSaldo());
	}

}
