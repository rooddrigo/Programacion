package paquetes;

public class Principal {

	public static void main(String[] args) {
		Empleado empleado = new Empleado("Pepito", 999, "Repartidor");
        System.out.println("Mostrar solo el salario: " + empleado.getSalario());
        System.out.println("Mostrar todos los datos con el método: ");
        empleado.mostrarDatos();

        System.out.println("\nAcceso desde la subclase ahora obteniendo todos los datos sin error:");
        Subclase subclase = new Subclase("Pepe ", 2222, "Programador");
        subclase.mostrarDatosSubclase(); 
	}

}
