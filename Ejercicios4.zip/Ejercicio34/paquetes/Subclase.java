package paquetes;

public class Subclase extends Empleado{

	public Subclase(String nombre, double salario, String departamento) {
		super(nombre, salario, departamento);
		// TODO Auto-generated constructor stub
	}
	public void mostrarDatosSubclase() {
		System.out.println("Nombre: " + nombre); 
        System.out.println("Departamento: " + departamento); 
        System.out.println("Salario: " + getSalario()); 
	}
}