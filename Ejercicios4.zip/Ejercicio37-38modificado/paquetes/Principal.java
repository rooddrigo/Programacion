package paquetes;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Coche cocheNuevo = new Coche("Bmw", "Serie 3 320e", 4);
		cocheNuevo.mostrarDatos();
		cocheNuevo.describir();
	}

}
