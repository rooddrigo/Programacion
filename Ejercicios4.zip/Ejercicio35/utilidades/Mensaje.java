package utilidades;

public class Mensaje {
	String mensaje = "¡Hola desde mis utilidades!";
	public void imprimirMensaje() {
		System.out.println(mensaje);
	}
}
