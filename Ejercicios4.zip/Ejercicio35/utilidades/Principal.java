package utilidades;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Mensaje mensajito = new Mensaje();
		mensajito.imprimirMensaje();
	}

}
