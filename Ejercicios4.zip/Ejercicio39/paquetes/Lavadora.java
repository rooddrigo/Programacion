package paquetes;

public class Lavadora extends Electrodomestico{
	double capacidadKg;
	public Lavadora(String marca, double precio, double capacidadKg) {
		super(marca, precio);
		this.capacidadKg = capacidadKg;
		// TODO Auto-generated constructor stub
	}
	public void mostrarDatos() {
		System.out.println("Soy una lavadora de la marca "+marca+", cuesto "+precio+"€, y tengo una capacidad de "+capacidadKg+"Kg");
	}

}
