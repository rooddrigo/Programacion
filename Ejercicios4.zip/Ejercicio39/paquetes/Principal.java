package paquetes;

public class Principal {

	public static void main(String[] args) {
		Lavadora lavadora = new Lavadora("Haier", 300, 12);
		lavadora.mostrarDatos();
		Televisor tele = new Televisor("Samsung", 1000, 85);
		tele.mostrarDatos();

	}

}
