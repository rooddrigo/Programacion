package paquetes;

public class Televisor extends Electrodomestico{
	double pulgadas;
	public Televisor(String marca, double precio, double pulgadas) {
		super(marca, precio);
		this.pulgadas = pulgadas;
		// TODO Auto-generated constructor stub
	}
	public void mostrarDatos() {
		System.out.println("Soy una tele de la marca "+marca+", cuesto "+precio+"€, y tengo "+pulgadas+" pulgadas");
	}

}