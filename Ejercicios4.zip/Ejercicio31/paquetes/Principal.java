package paquetes;

public class Principal {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		        Persona persona1 = new Persona();
		        persona1.nombre = "Juan";
		        persona1.edad = 25;
		        persona1.mostrarInfo();
		        Persona persona2 = new Persona();
		        persona2.nombre = "Hola";
		        persona2.edad = 15;
		        persona2.mostrarInfo();
	

	}

}
