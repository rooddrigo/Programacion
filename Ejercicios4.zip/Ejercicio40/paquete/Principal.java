package paquete;

public class Principal {
    public static void main(String[] args) {
        Figura f1 = new Circulo(2);
        Figura f2 = new Rectangulo(3, 4);
        System.out.println("Área círculo: " + f1.calcularArea());
        System.out.println("Área rectángulo: " + f2.calcularArea());
    }
}



