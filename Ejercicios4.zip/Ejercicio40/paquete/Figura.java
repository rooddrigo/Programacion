package paquete;

public abstract class Figura {
    abstract double calcularArea();
    
    void mostrarTipo() {
        System.out.println("Soy una figura");
    }
}
