package paquetes;

public class Principal {
    public static void main(String[] args) {
        Persona persona1 = new Persona();
        System.out.println("Persona1 -> Nombre: " + persona1.nombre + ", Edad: " + persona1.edad);
        Persona persona2 = new Persona("Pepe");
        System.out.println("Persona2 -> Nombre: " + persona2.nombre + ", Edad: " + persona2.edad);
        Persona persona3 = new Persona("Pepito", 69);
        System.out.println("Persona3 -> Nombre: " + persona3.nombre + ", Edad: " + persona3.edad);
    }
}
