<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        html {
            height: 100%;
            margin: 0;
            overflow: auto; /* Permite el scroll global */
        }

        body {
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            color: white;
            font-family: 'Poppins', sans-serif;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            flex-direction: column;
            min-height: 100vh; /* Asegura que el body tenga al menos la altura de la pantalla */
            padding: 0;
        }

        .container {
            background-color: rgba(88, 100, 98, 0.7);
            padding: 30px;
            border-radius: 8px;
            width: 70%;
            max-width: 900px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
            margin-top: 20px;
            margin-bottom: 20px;
        }

        h1, h2, p, h3 {
            text-align: center;
            color: black;
        }

        h1 {
            font-size: 2.5rem;
            font-weight: 600;
            margin-top: 20px;
        }

        .btn {
            background-color: rgb(9, 112, 229);
            color: white;
            border: none;
            padding: 8px 15px;
            font-size: 0.9rem;
            margin-top: 10px;
            border-radius: 5px;
        }

        .btn-primary:hover {
            background-color: rgb(81, 175, 242);
        }

        .btn-secondary {
            background-color:rgb(249, 100, 0);
            color: white;
            border: none;
            padding: 8px 15px;
            font-size: 0.9rem;
            margin-top: 10px;
            border-radius: 5px;
        }

        .btn-secondary:hover {
            background-color: rgb(249, 153, 85);
        }

        .btn-danger {
            background-color: rgb(220, 20, 60);
            color: white;
            border: none;
            padding: 8px 15px;
            font-size: 0.9rem;
            margin-top: 10px;
            border-radius: 5px;
        }

        .btn-danger:hover {
            background-color: rgb(255, 70, 100);
        }

        .btn-success {
            background-color: rgb(10, 170, 90);
            color: white;
            border: none;
            padding: 8px 15px;
            font-size: 0.9rem;
            margin-top: 10px;
            border-radius: 5px;
        }

        .btn-success:hover {
            background-color: rgb(80, 210, 120);
        }

        .form-control, .form-select {
            margin-bottom: 15px;
        }

        .form-label {
            font-weight: bold;
        }

    </style>

    <title>Iniciar Sesión</title>
</head>
<body>
    <div class="container">
    <?php
    session_start(); 
    // Inicia la sesión para gestionarla en todo el sitio

    require_once '../config/conexion.php';

    // Obtenemos lo que ha enviado el usuario.
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $correo = $_POST['correo'];
        $contraseña = $_POST['contraseña'];
        $_SESSION['correo'] = $correo; // Guardamos el correo en la sesión temporalmente

        // Conexión a la base de datos
        $conexion = new Conexion();
        $conexion = $conexion->getConexion();

        // Creamos la clase para manejar el inicio de sesión
        class IniciarSesion {
            private $conexion;

            public function __construct($conexion) {
                $this->conexion = $conexion;
            }

            // Función para validar al usuario mediante un select.
            public function validarUsuario($correo, $contraseña) {
                $query = "SELECT id, nombre_usuario, correo, contraseña FROM usuarios WHERE correo = ?";
                $stmt = $this->conexion->prepare($query);
                $stmt->bind_param("s", $correo);
                $stmt->execute();
                $result = $stmt->get_result();

                // Si encontramos un usuario con ese correo
                if ($row = $result->fetch_assoc()) {

                    // Verificamos la contraseña
                    if (password_verify($contraseña, $row['contraseña'])) {

                        // Guardamos los datos del usuario en la variable de session
                        $_SESSION['usuario_id'] = $row['id'];
                        $_SESSION['nombre_usuario'] = $row['nombre_usuario'];
                        $_SESSION['correo'] = $row['correo'];

                        // Redirigimos a la página de tareas
                        header('Location: mostrar_tareas.php');
                        exit();
                    } else {
                        // Comprobamos los posibles errores, o por usuario o por contraseña.

                        echo "<div class='alert alert-danger'>Contraseña incorrecta.</div>";
                    }
                } else {
                    echo "<div class='alert alert-danger'>No se ha encontrado ese correo en nuestra base de datos.</div>";
                }
                $stmt->close();
            }
        }

        // Llamamos a la función.
        $controller = new IniciarSesion($conexion);
        $controller->validarUsuario($correo, $contraseña);
    }
    ?>

    </div>
</body>
</html>
