<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        /* De nuevo todo el codigo de css para la edición */

        html {
            height: 100%;
            margin: 0;
            overflow: auto;
        }

        body {
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            color: white;
            font-family: 'Poppins', sans-serif;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            flex-direction: column;
            min-height: 100vh;
            padding: 0;
        }

        .container {
            background-color: rgba(88, 100, 98, 0.7);
            padding: 30px;
            border-radius: 8px;
            width: 70%;
            max-width: 900px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
            margin-top: 20px;
            margin-bottom: 20px;
        }

        h1, h2, p, h3 {
            text-align: center;
            color: black;
        }

        h1 {
            font-size: 2.5rem;
            font-weight: 600;
            margin-top: 20px;
        }

        .btn {
            background-color: rgb(9, 112, 229);
            color: white;
            border: none;
            padding: 8px 15px;
            font-size: 0.9rem;
            margin-top: 10px;
            border-radius: 5px;
        }

        .btn-primary:hover {
            background-color: rgb(81, 175, 242);
        }

        .btn-secondary {
            background-color: rgb(249, 100, 0);
            color: white;
            border: none;
            padding: 8px 15px;
            font-size: 0.9rem;
            margin-top: 10px;
            border-radius: 5px;
        }

        .btn-secondary:hover {
            background-color: rgb(249, 153, 85);
        }

        .btn-danger {
            background-color: rgb(220, 20, 60);
            color: white;
            border: none;
            padding: 8px 15px;
            font-size: 0.9rem;
            margin-top: 10px;
            border-radius: 5px;
        }

        .btn-danger:hover {
            background-color: rgb(255, 70, 100);
        }

        .btn-success {
            background-color: rgb(10, 170, 90);
            color: white;
            border: none;
            padding: 8px 15px;
            font-size: 0.9rem;
            margin-top: 10px;
            border-radius: 5px;
        }

        .btn-success:hover {
            background-color: rgb(80, 210, 120);
        }

        .form-control, .form-select {
            margin-bottom: 15px;
        }

        .form-label {
            font-weight: bold;
        }

        ul {
            list-style: none;
            padding-left: 0;
        }

        li {
            margin-bottom: 15px;
        }

    </style>
    <title>Tareas del Usuario</title>
</head>
<body>
    <div class="container">
        <?php
        session_start();
        require_once '../config/conexion.php';

        // Verificamos que el usuario está autenticado
        if (!isset($_SESSION['usuario_id'])) {
            header("Location: iniciar_sesion.php");
            exit();
        }
        // Obtenemos las tareas del usuario mediante su id con el query y el stmt.
        $usuario_id = $_SESSION['usuario_id'];
        $conexion = new Conexion();
        $conexion = $conexion->getConexion();

        $query = "
            SELECT id, titulo, descripcion, estado, fecha_creacion
            FROM tareas
            WHERE usuario_id = ?;
        ";

        $stmt = $conexion->prepare($query);
        $stmt->bind_param("i", $usuario_id);
        $stmt->execute();
        $result = $stmt->get_result();

        // Añadimos un boton para agregar tareas.
        echo "<h2>Tareas del Usuario</h2>";
        echo "<a href='crear_tareas.php' class='btn btn-success'>Agregar Nueva Tarea</a>";

        // Mediante un bucle while, imprimimos todos los datos del usuario
        echo "<ul>";
        while ($row = $result->fetch_assoc()) {
            echo "<li>";
            echo "<strong>Título:</strong> " . htmlspecialchars($row['titulo']) . "<br>";
            echo "<strong>Descripción:</strong> " . htmlspecialchars($row['descripcion']) . "<br>";
            echo "<strong>Estado:</strong> " . htmlspecialchars($row['estado']) . "<br>";
            echo "<strong>Fecha de Creación:</strong> " . htmlspecialchars($row['fecha_creacion']) . "<br>";
            echo "<a href='editar_tareas.php?id=" . $row['id'] . "' class='btn btn-primary'>Editar</a> ";
            
            // Nos aseguramos de que al darle a editar o eliminar, nos dirija a esa tarea mediante su id. 

            echo "<a href='eliminar_tareas.php?id=" . $row['id'] . "' class='btn btn-danger'>Eliminar</a>";
            echo "</li>";
        }
        echo "</ul>";

        $stmt->close();
        ?>
        <a href="index.html" class="btn btn-success">Volver al Inicio</a>
    </div>
</body>
</html>
