<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        /* De nuevo ponemos los estilos y demás */
        html {
            height: 100%;
            margin: 0;
            overflow: auto;
        }

        body {
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            color: white;
            font-family: 'Poppins', sans-serif;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            flex-direction: column;
            min-height: 100vh;
            padding: 0;
        }

        .container {
            background-color: rgba(88, 100, 98, 0.7);
            padding: 30px;
            border-radius: 8px;
            width: 70%;
            max-width: 900px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
            margin-top: 20px;
            margin-bottom: 20px;
        }

        h1, h2, p, h3 {
            text-align: center;
            color: black;
        }

        h1 {
            font-size: 2.5rem;
            font-weight: 600;
            margin-top: 20px;
        }

        .btn {
            background-color: rgb(9, 112, 229);
            color: white;
            border: none;
            padding: 8px 15px;
            font-size: 0.9rem;
            margin-top: 10px;
            border-radius: 5px;
        }

        .btn-primary:hover {
            background-color: rgb(81, 175, 242);
        }

        .btn-danger {
            background-color: rgb(220, 20, 60);
            color: white;
            border: none;
            padding: 8px 15px;
            font-size: 0.9rem;
            margin-top: 10px;
            border-radius: 5px;
        }

        .btn-danger:hover {
            background-color: rgb(255, 70, 100);
        }

        .form-container {
            margin-top: 20px;
        }
    </style>
    <title>Eliminar Tarea</title>
</head>
<body>
    <div class="container">
        <?php
        session_start();
        require_once '../config/conexion.php';

        // Verificamos que el usuario está autenticado
        if (!isset($_SESSION['usuario_id'])) {
            header("Location: iniciar_sesion.php");
            exit();
        }
        
        // Comprobamos el id
        if (isset($_GET['id'])) {
            $tarea_id = $_GET['id'];
            $usuario_id = $_SESSION['usuario_id'];

            $conexion = new Conexion();
            $conexion = $conexion->getConexion();

            // Eliminar tarea mediante un Delete.
            $query = "DELETE FROM tareas WHERE id = ? AND usuario_id = ?";
            $stmt = $conexion->prepare($query);
            $stmt->bind_param("ii", $tarea_id, $usuario_id);

            // Compobramos que todo haya salido bien
            if ($stmt->execute()) {
                header("Location: mostrar_tareas.php");
            } else {
                echo "<div class='alert alert-danger'>Hubo un error al eliminar la tarea.</div>";
            }

            $stmt->close();
            // Cerramos la conexión.

        } else {
            // Comprobamos que se haya obtenido el id de la tarea de forma correcta
            echo "<div class='alert alert-danger'>No se ha proporcionado el ID de la tarea.</div>";
        }
        ?>
    </div>
</body>
</html>
