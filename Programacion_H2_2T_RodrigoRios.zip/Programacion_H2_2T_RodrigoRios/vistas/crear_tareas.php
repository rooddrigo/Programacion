<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
/* A continuación tenemos lo que seria el css de la pagina en la que damos las medidas, fuentes y colores a los elementos visibles */
        html {
            height: 100%;
            margin: 0;
            overflow: auto;
        }
        body {
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            color: white;
            font-family: 'Poppins', sans-serif;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            flex-direction: column;
            min-height: 100vh;
            padding: 0;
        }
/* Este caso es para el contenedor, no para toda la página */
        .container {
            background-color: rgba(88, 100, 98, 0.7);
            padding: 30px;
            border-radius: 8px;
            width: 70%;
            max-width: 900px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
            margin-top: 20px;
            margin-bottom: 20px;
        }
/* Colores, tamaños y disposición de las fuentes... */
        h1, h2, p, h3 {
            text-align: center;
            color: black;
        }

        h1 {
            font-size: 2.5rem;
            font-weight: 600;
            margin-top: 20px;
        }
/* Estos son los efectos y colores de los diferentes botones */
        .btn {
            background-color: rgb(9, 112, 229);
            color: white;
            border: none;
            padding: 8px 15px;
            font-size: 0.9rem;
            margin-top: 10px;
            border-radius: 5px;
        }

        .btn-primary:hover {
            background-color: rgb(81, 175, 242);
        }

        .btn-secondary {
            background-color: rgb(249, 100, 0);
            color: white;
            border: none;
            padding: 8px 15px;
            font-size: 0.9rem;
            margin-top: 10px;
            border-radius: 5px;
        }

        .btn-secondary:hover {
            background-color: rgb(249, 153, 85);
        }

        .btn-danger {
            background-color: rgb(220, 20, 60);
            color: white;
            border: none;
            padding: 8px 15px;
            font-size: 0.9rem;
            margin-top: 10px;
            border-radius: 5px;
        }

        .btn-danger:hover {
            background-color: rgb(255, 70, 100);
        }

        .btn-success {
            background-color: rgb(10, 170, 90);
            color: white;
            border: none;
            padding: 8px 15px;
            font-size: 0.9rem;
            margin-top: 10px;
            border-radius: 5px;
        }

        .btn-success:hover {
            background-color: rgb(80, 210, 120);
        }
/* Margen y posición del formulario */
        .form-control, .form-select {
            margin-bottom: 15px;
        }

        .form-label {
            font-weight: bold;
        }

        .form-container {
            margin-top: 20px;
        }
    </style>
    <title>Crear Nueva Tarea</title>
</head>
<body>
    <!-- Dentro del body y del container incluimos el php que validará y añadirá la tarea deseada. -->
    <div class="container">
        <?php

        // Hacemos uso de un session_start para que el usuario una vez haya iniciado sesión,
        // pueda hacer cambios en su perfil sin tener que volver a meter sus datos.
        session_start();

        // Accedemos a la conexión con la base de datos.
        require_once '../config/conexion.php';

        // Verificamos que el usuario está autenticado si no mediante el session, si no, le mandamos al inicio de sesión.
        if (!isset($_SESSION['usuario_id'])) {
            header("Location: iniciar_sesion.php");
            exit();
        }
        // Accedemos a lo que el usuario ha puesto en las tareas mediante un POST.
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $titulo = $_POST['titulo'];
            $descripcion = $_POST['descripcion'];
            $estado = $_POST['estado'];
            $usuario_id = $_SESSION['usuario_id'];

        // Con el getConexion accedemos al servidor 
            $conexion = new Conexion();
            $conexion = $conexion->getConexion();

        // Hacemos un query para insertar las tareas que el usuario haya introducido en el formulario 
        // (El formulario está al final del php)
            $query = "
                INSERT INTO tareas (titulo, descripcion, estado, usuario_id)
                VALUES (?, ?, ?, ?);
            ";

            $stmt = $conexion->prepare($query);
            $stmt->bind_param("sssi", $titulo, $descripcion, $estado, $usuario_id);
        // Introducimos los datos mediante un bind_param.

            if ($stmt->execute()) {
                header("Location: mostrar_tareas.php");
                // Controlamos esa inserción para evitar errores de la pagina.
            } else {
                echo "<div class='alert alert-danger'>Hubo un error al agregar la tarea.</div>";
            }
        // Cerramos el stmt pase lo que pase.
            $stmt->close();
        }
        ?>

        <!-- Creamos el formulario con lo necesario para que la tarea se pueda introducir correctamente. -->
        <!-- Todo ha de ser required para que no de errores o valores null en el sql. -->

        <div class="form-container">
            <h2>Crear Nueva Tarea</h2>
            <form action="crear_tareas.php" method="POST">
                <div class="mb-3">
                    <label for="titulo" class="form-label">Título</label>
                    <input type="text" name="titulo" id="titulo" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="descripcion" class="form-label">Descripción</label>
                    <textarea name="descripcion" id="descripcion" class="form-control" required></textarea>
                </div>
                <div class="mb-3">
                    <label for="estado" class="form-label">Estado</label>
                    <select name="estado" id="estado" class="form-select" required>
                        <option value="Pendiente">Pendiente</option>
                        <option value="Completada">Completada</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-success">Agregar Tarea</button>
            </form>
        </div>
    </div>
</body>
</html>
