<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        /* Al igual que en las demás, tenemos el body con un fondo, personalizado el tamaño, fuente, color etc.. */
        body {  
            background-image: url('../fotofondoagenda.PNG'); 
            background-size: cover; 
            background-position: center; 
            background-repeat: no-repeat; 
            color: white;
            font-family: 'Poppins', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        h1, h2, p {
            text-align: center;
            color: white;
        }
        h1 {
            font-size: 2.5rem;
            font-weight: 600;
            margin-top: 20px;
        }
        /* En este caso tambien tenemos container asi que llevara si personalización propia */
        .container {
            background-color: rgba(88, 100, 98, 0.7);
            padding: 20px;
            border-radius: 8px;
            max-width: 600px;
            width: 100%;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
        }
        .result {
            margin-top: 30px;
            font-size: 1.2rem;
        }
        /* Para personalizar el botón y darle un efecto */
        .btn {
            background-color:rgb(9, 112, 229);
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 1.1rem;
            margin-top: 20px;
            width: 100%;
            border-radius: 5px;
        }
        .btn:hover {
            background-color:rgb(81, 242, 89);
        }
    </style>
    <title>Darse de Alta</title>
</head>

<body>
    <!-- Incluimos todo el php en el body para poder darle formato de html y sea todo más bonito -->
    <div class="container">
        <?php
        require_once '../config/conexion.php';
        //Usamos un requiere_once para que acceda a la base de datos para que lo utilice una vez y no se cargue mas, o para que de error si no es posible.

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        //Comprobamos que lo que enviamos antes fue con 'POST' para poder seguir y lo recogemos en variables.
            $nombre_usuario = $_POST['nombre_usuario'];
            $correo = $_POST['correo'];

        // La contraseña irá con un password_hash y PASSWORD_BCRYPT para que se envie de forma encriptada.
            $contraseña = password_hash($_POST['contraseña'], PASSWORD_BCRYPT);
        }

        // Mensaje de aviso para ver los datos puestos.

            echo "<h1>Tus Datos:</h1>";
            echo "<p><strong>Nombre:</strong> $nombre_usuario</p>";
            echo "<p><strong>Correo electrónico:</strong> $correo</p>";
            echo "<p><strong>Tareas:</strong> 0</p>";

        // Usamos la clase conexion para poder acceder a la base de datos y realizar cambios.

            $conexion = new Conexion(); 
            $conexion = $conexion->getConexion();

        // Creamos la clase socio para poder añadir a los usuarios a la base de datos
        class Socio {
            private $conexion;

            public function __construct($conexion) {
                $this->conexion = $conexion;
            }
        // De nuevo un construct de la conexion.

            public function agregarSocio($nombre_usuario, $correo, $contraseña) {
        // Seleccionamos las variables que queremos ingresar y lo hacemos como siempre con query, stmt y bind_param
                
                $query = "INSERT INTO usuarios (nombre_usuario, correo, contraseña) VALUES (?, ?, ?)";
                $stmt = $this->conexion->prepare($query);
                $stmt->bind_param("sss", $nombre_usuario, $correo, $contraseña);

                if ($stmt->execute()) {
        // Mensaje de que todo ha salido bien.
                    echo '<h1>Socio agregado con éxito</h1>';
        // Controlamos los errores y cerramos el stmt.
                } else {
                    echo "<h2>Error al agregar socio</h2>";
                }
                $stmt->close();
            }
        }

        $controller = new Socio($conexion);
        $usuario_id = $controller->agregarSocio($nombre_usuario, $correo, $contraseña);
        ?>
        <!-- Añadimos un botón para volver al index al terminar -->
        <a class="btn" href="index.html">Volver a StreamWeb</a>
    </div>
</body>
</html>
