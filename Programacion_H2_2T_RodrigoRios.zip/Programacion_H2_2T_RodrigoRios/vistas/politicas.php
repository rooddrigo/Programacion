Hola, soy las políticas
<!-- Estas son las políticas -->