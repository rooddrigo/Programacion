<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        html {
            height: 100%;
            margin: 0;
            overflow: auto;
        }

        body {
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            color: white;
            font-family: 'Poppins', sans-serif;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            flex-direction: column;
            min-height: 100vh;
            padding: 0;
        }

        .container {
            background-color: rgba(88, 100, 98, 0.7);
            padding: 30px;
            border-radius: 8px;
            width: 70%;
            max-width: 900px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
            margin-top: 20px;
            margin-bottom: 20px;
        }

        h1, h2, p, h3 {
            text-align: center;
            color: black;
        }

        h1 {
            font-size: 2.5rem;
            font-weight: 600;
            margin-top: 20px;
        }

        .btn {
            background-color: rgb(9, 112, 229);
            color: white;
            border: none;
            padding: 8px 15px;
            font-size: 0.9rem;
            margin-top: 10px;
            border-radius: 5px;
        }

        .btn-primary:hover {
            background-color: rgb(81, 175, 242);
        }

        .btn-secondary {
            background-color: rgb(249, 100, 0);
            color: white;
            border: none;
            padding: 8px 15px;
            font-size: 0.9rem;
            margin-top: 10px;
            border-radius: 5px;
        }

        .btn-secondary:hover {
            background-color: rgb(249, 153, 85);
        }

        .btn-danger {
            background-color: rgb(220, 20, 60);
            color: white;
            border: none;
            padding: 8px 15px;
            font-size: 0.9rem;
            margin-top: 10px;
            border-radius: 5px;
        }

        .btn-danger:hover {
            background-color: rgb(255, 70, 100);
        }

        .btn-success {
            background-color: rgb(10, 170, 90);
            color: white;
            border: none;
            padding: 8px 15px;
            font-size: 0.9rem;
            margin-top: 10px;
            border-radius: 5px;
        }

        .btn-success:hover {
            background-color: rgb(80, 210, 120);
        }

        .form-control, .form-select {
            margin-bottom: 15px;
        }

        .form-label {
            font-weight: bold;
        }

        .form-container {
            margin-top: 20px;
        }

        .back-btn {
            background-color: rgb(0, 168, 255);
            font-size: 1rem;
            padding: 8px 15px;
            border-radius: 5px;
            color: white;
            margin-top: 15px;
        }

        .back-btn:hover {
            background-color: rgb(20, 130, 200);
        }
    </style>
    <title>Editar Tarea</title>
</head>
<body>
    <div class="container">
        <?php
        session_start();
        require_once '../config/conexion.php';

        // Verificamos que el usuario está autenticado
        if (!isset($_SESSION['usuario_id'])) {
            header("Location: iniciar_sesion.php");
            exit();
        }

        $usuario_id = $_SESSION['usuario_id'];
        // Obtenemos el id del usuario para saber que tareas tiene.

        if (isset($_GET['id'])) {
            $tarea_id = $_GET['id'];

            // Conectamos a la base de datos
            $conexion = new Conexion();
            $conexion = $conexion->getConexion();

            // Buscamos la tarea mediante las id´s
            $query = "
                SELECT id, titulo, descripcion, estado
                FROM tareas
                WHERE id = ? AND usuario_id = ?;
            ";

            // Obtenmos los datos que haya gracias al stmt y el get_result
            $stmt = $conexion->prepare($query);
            $stmt->bind_param("ii", $tarea_id, $usuario_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            // Comprobamos que los resultados obtenidos se correspondan
            if ($row = $result->fetch_assoc()) {
                $titulo = $row['titulo'];
                $descripcion = $row['descripcion'];
                $estado = $row['estado'];
            } 
            $stmt->close();
        }
        // Ahora mediante lo obtenido en el formulario, hacemos un update para que modificar las tareas deseadas
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nuevo_titulo = $_POST['titulo'];
            $nueva_descripcion = $_POST['descripcion'];
            $nuevo_estado = $_POST['estado'];

            $query_update = "
                UPDATE tareas
                SET titulo = ?, descripcion = ?, estado = ?
                WHERE id = ? AND usuario_id = ?;
            ";
            
            // Introducimos los datos a actualizar.
            $stmt_update = $conexion->prepare($query_update);
            $stmt_update->bind_param("sssii", $nuevo_titulo, $nueva_descripcion, $nuevo_estado, $tarea_id, $usuario_id);

            // Comprobamos que todo se haya actualizado 
            if ($stmt_update->execute()) {
                echo "<div class='alert alert-success'>Tarea actualizada exitosamente.</div>";
                header("Location: mostrar_tareas.php");
                exit();
            } else {
                echo "<div class='alert alert-danger'>Hubo un error al actualizar la tarea.</div>";
            }

            $stmt_update->close();
        }
        ?>

        <!-- Creamos el formulario -->

        <div class="form-container">
            <h2>Editar Tarea</h2>
            <form action="editar_tareas.php?id=<?php echo $tarea_id; ?>" method="POST">
                <div class="mb-3">
                    <label for="titulo" class="form-label">Título</label>
                    <input type="text" name="titulo" id="titulo" class="form-control" value="<?php echo htmlspecialchars($titulo); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="descripcion" class="form-label">Descripción</label>
                    <textarea name="descripcion" id="descripcion" class="form-control" required><?php echo htmlspecialchars($descripcion); ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="estado" class="form-label">Estado</label>
                    <select name="estado" id="estado" class="form-select" required>
                        <option value="Pendiente" <?php echo $estado === 'Pendiente' ? 'selected' : ''; ?>>Pendiente</option>
                        <option value="Completada" <?php echo $estado === 'Completada' ? 'selected' : ''; ?>>Completada</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary mt-3">Actualizar Tarea</button>
            </form>
        </div>
    </div>
</body>
</html>
