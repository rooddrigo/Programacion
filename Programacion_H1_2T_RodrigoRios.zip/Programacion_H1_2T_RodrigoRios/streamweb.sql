-- Borra la base de datos si ya existe, para empezar desde cero.
DROP DATABASE IF EXISTS streamweb;

-- Crea la base de datos
CREATE DATABASE streamweb;
USE streamweb;

-- Tabla de usuarios
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,  -- ID único por usuario
    nombre_apellido VARCHAR(255) NOT NULL, 
    correo_email VARCHAR(255) UNIQUE NOT NULL,  -- Correo único por usuario
    edad INT NOT NULL CHECK (edad >= 0),  -- No permite edades negativas
    tipo_plan VARCHAR(20) NOT NULL,  -- Plan del usuario
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP  
);

-- Tabla de paquetes adicionales
CREATE TABLE paquetes_adicionales (
    id INT AUTO_INCREMENT PRIMARY KEY, 
    nombre VARCHAR(50) NOT NULL,  
    precio FLOAT NOT NULL 
);

-- Tabla de suscripciones de los usuarios a paquetes adicionales
CREATE TABLE subscripciones (
    usuario_id INT NOT NULL,  -- ID del usuario que compra el paquete
    paquete_adicional VARCHAR(20) NOT NULL,  -- Nombre del paquete
    tipo_de_plan VARCHAR(20) NOT NULL,  -- Tipo de plan contratado
    duracion VARCHAR(20) NOT NULL,  -- Duración de la suscripción 
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE  -- Si se borra el usuario, se eliminan sus suscripciones
);

-- Tabla de precios de los diferentes planes de suscripción
CREATE TABLE precios_planes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo_plan VARCHAR(20) NOT NULL,  
    precio DECIMAL(5,2) NOT NULL  -- Precio con dos decimales
);


INSERT INTO precios_planes (tipo_plan, precio) VALUES
('Básico', 9.99),
('Estándar', 13.99),
('Premium', 17.99);


INSERT INTO paquetes_adicionales (nombre, precio) VALUES
('Deporte', 6.99),
('Cine', 7.99),
('Infantil', 4.99);


INSERT INTO usuarios (nombre_apellido, correo_email, edad, tipo_plan) VALUES 
('Juan Pérez', 'juan.perez@ejemplo.com', 25, 'Estándar'),
('Ana González', 'ana.gonzalez@ejemplo.com', 16, 'Básico'),
('Carlos Martínez', 'carlos.martinez@ejemplo.com', 30, 'Premium');


INSERT INTO subscripciones (usuario_id, paquete_adicional, tipo_de_plan, duracion) VALUES 
(1, 'Deporte', 'Estándar', 'Mensual'),  
(2, 'Infantil', 'Básico', 'Mensual'),  
(3, 'Cine', 'Premium', 'Anual');