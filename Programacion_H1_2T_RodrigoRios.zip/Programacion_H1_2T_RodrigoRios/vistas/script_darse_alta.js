// Aqui al igual que en la función del index, comprobamos todo y validamos

document.getElementById('myForm').addEventListener('submit', function(event) {
    const name = document.getElementById('nombre_apellido').value.trim();
    const email = document.getElementById('email').value.trim();
    const edad = parseInt(document.getElementById('edad').value.trim()); 
    const planes = document.getElementById('plan').value.trim();
    const subscripcion = document.getElementById('subscripcion').value.trim();
    const duracion = document.getElementById('duracion').value.trim();

    if (!name || !email || !edad || !planes || !subscripcion || !duracion) {
        alert('Por favor, completa todos los campos.');
        event.preventDefault(); // Prevenir envío
    } 
    else if (!email.includes('@')) {
        alert('Por favor, introduce un correo electrónico válido.');
        event.preventDefault(); 
    } 
    else if (edad < 18 && subscripcion !== "Infantil") {
        alert('Para seleccionar un plan distinto al infantil, has de ser mayor de edad.');
        event.preventDefault(); 
    } 
    // Validar que la duración de la subscripción de deportes sea anual
    else if (subscripcion === "Deporte" && duracion !== "Anual") {
        alert('Para seleccionar la subscripción de deportes, la renovación ha de ser anual.');
        event.preventDefault(); 
    }
});
