<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
    html {
        height: 100%;
        margin: 0;
        overflow: hidden; 
        /* Ocultamos el scroll porque a veces me daba error. */
    }
/* Añadimos más estilos al body y al contenedor */
    body {
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        color: white;
        font-family: 'Poppins', sans-serif;
        display: flex;
        justify-content: center;
        align-items: flex-start;
        flex-direction: column;
        height: auto; 
    }

    .container {
        background-color: rgba(88, 100, 98, 0.7);
        padding: 30px;
        border-radius: 8px;
        width: 70%;
        max-width: 900px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
        margin-top: 20px;
        margin-bottom: 20px;
        max-height: 100vh; 
        overflow-y: auto; 
    }

    h1, h2, p {
        text-align: center;
        color: black;
    }

    h1 {
        font-size: 2.5rem;
        font-weight: 600;
        margin-top: 20px;
    }

    .btn {
        background-color: rgb(9, 112, 229);
        color: white;
        border: none;
        padding: 8px 15px;
        font-size: 0.9rem;
        margin-top: 10px;
        border-radius: 5px;
    }

    .btn:hover {
        background-color: rgb(81, 242, 89);
    }

    .form-control, .form-select {
        margin-bottom: 15px;
    }

    .form-label {
        font-weight: bold;
    }
</style>

    <title>Iniciar Sesión</title>
</head>
<body>
    <div class="container">
        <?php
        session_start();
        require_once '../config/conexion.php';
// Comprobamos que nos ha llegado el email y cleamos la clase iniciar_sesion.
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = htmlspecialchars($_POST['email']);
            $_SESSION['email'] = $email;
        }

        $conexion = new Conexion(); 
        $conexion = $conexion->getConexion();

        class iniciar_sesion {
            private $conexion;
            public function __construct($conexion) {
                $this->conexion = $conexion;
            }
            public function inicioSesion($email){
                $query = "SELECT correo_email FROM usuarios WHERE correo_email = ?";
                $stmt = $this->conexion->prepare($query);
                $stmt->bind_param("s", $email);
                $stmt->execute();
                $result = $stmt->get_result();
// Comprobamos que el correo introducido existe en el sql
                if ($row = $result->fetch_assoc()) {
                    $usuario_id = $row['correo_email'];  
                    $stmt->close();
                    return $usuario_id;  
                } else {
                    echo "No se ha encontrado ese correo en nuestra base de datos";
                    $stmt->close();
                }
            }
        }
        $controller = new iniciar_sesion($conexion);
        $correo_usuario = $controller->inicioSesion($email);
if ($correo_usuario) {
    // Hacemos un select con inner joins para poder seleccionar toda la información del usuario, no solo de la tabla usuarios.
    $query2 = "
        SELECT 
            u.id, 
            u.nombre_apellido, 
            u.correo_email, 
            u.edad, 
            u.tipo_plan, 
            u.fecha_registro, 
            p.precio AS precio_plan_base, 
            s.duracion, 
            s.paquete_adicional, 
            pa.precio AS precio_paquete 
        FROM 
            usuarios u
        JOIN 
            precios_planes p ON u.tipo_plan = p.tipo_plan
        INNER JOIN 
            subscripciones s ON u.id = s.usuario_id
        INNER JOIN 
            paquetes_adicionales pa ON s.paquete_adicional = pa.nombre
        WHERE 
            u.correo_email = ?
    ";

    $stmt2 = $conexion->prepare($query2);

    if ($stmt2) {
        $stmt2->bind_param("s", $correo_usuario);
        $stmt2->execute();
        $result = $stmt2->get_result();
// Todo lo obtenido lo imprimimos con un fetch_assoc()
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $_SESSION['nombre_apellido'] = $row['nombre_apellido'];
                $_SESSION['edad'] = $row['edad'];
                $_SESSION['tipo_plan'] = $row['tipo_plan'];
                $_SESSION['duracion'] = $row['duracion'];
                $_SESSION['paquete_adicional'] = $row['paquete_adicional'];

                echo "<div class='container mt-4 p-3 bg-light rounded shadow'>";
                echo "<h2 class='text-center'>Datos del Usuario</h2>";
                echo "<ul class='list-group'>";
                echo "<li class='list-group-item'><strong>Nombre:</strong> " . ($row['nombre_apellido']) . "</li>";
                echo "<li class='list-group-item'><strong>Correo:</strong> " . ($row['correo_email']) . "</li>";
                echo "<li class='list-group-item'><strong>Edad:</strong> " . ($row['edad']) . " años</li>";
                echo "<li class='list-group-item'><strong>Plan:</strong> " . ($row['tipo_plan']) . "</li>";
                echo "<li class='list-group-item'><strong>Precio del Plan Elegido:</strong> " . ($row['precio_plan_base']) . " USD</li>";
                echo "<li class='list-group-item'><strong>Fecha de Registro:</strong> " . ($row['fecha_registro']) . "</li>";
                
                echo "<li class='list-group-item'><strong>Paquete Adicional:</strong> " . ($row['paquete_adicional']) . "</li>";
                echo "<li class='list-group-item'><strong>Duración de la subscripción:</strong> " . ($row['duracion']) . "</li>";
                echo "<li class='list-group-item'><strong>Precio del Paquete Adicional:</strong> " . ($row['precio_paquete']) . " USD</li>";
                // Añadimos dos botones en caso de querer modificar el usuario o darse de baja con enlaces directos.
                echo "<a class='btn btn-primary' href='editar_usuario.php'>Modificar Usuario</a> ";
                echo "<a class='btn btn-primary' href='eliminar_usuario.php'>Eliminar Usuario</a> ";
                echo "</ul>";
                echo "</div>";
            }
        } else {
            echo "<div class='alert alert-warning'>No se encontraron datos para este usuario.</div>";
            echo "<a class='btn btn-primary' href='index.html'>Volver a StreamWeb</a> ";

        }
    }
}

                    echo "<div class='text-center mt-3'>";
                    echo "<a class='btn btn-primary' href='index.html'>Volver a StreamWeb</a> ";
                    echo "</div>";
            
    ?>
</body>
</html>
