
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        /* Estilos ya comentados anteriormente... */
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f7f7f7;
            font-family: 'Poppins', sans-serif;
            margin: 0;
        }
        .container {
            text-align: center;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 50%;
        }
        h1 {
            color: #4CAF50; 
            font-size: 2.5rem;
            margin-bottom: 20px;
        }
        .btn {
            background-color: rgb(9, 112, 229);
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 1.1rem;
            border-radius: 5px;
            text-decoration: none;
            width: 50%;
        }
        .btn:hover {
            background-color: rgb(81, 242, 89);
        }
        .btn-container {
            margin-top: 20px;
        }
    </style>
    <title>Eliminar Usuario</title>
</head>
<body>

    <?php
    session_start();
// comprobamos si hemos recibido el email y lo metemos en una variable.
    if (isset($_SESSION['email'])) {
        $email = $_SESSION['email'];
    } else {
        echo "No se ha encontrado el correo en la sesión.";
        exit();
    }
    require_once '../config/conexion.php';

    $conexion = new Conexion();
    $conexion = $conexion->getConexion();

    class eliminarSocio {
        private $conexion;

        public function __construct($conexion) {
            $this->conexion = $conexion; 
        }
// eliminamos al usuario mediante su correo porque es único
        public function eliminarSocio($email) {
            $query = "DELETE FROM usuarios WHERE correo_email = ?";
            $stmt = $this->conexion->prepare($query);
            $stmt->bind_param("s", $email); 
            if ($stmt->execute()) {
                echo "<h1>Socio eliminado con éxito</h1>";
                echo "<a href='index.html' class='btn btn-primary mb-3'>Volver al listado</a>";
                // Añadimos un botón al terminar todo.
            } else {
                echo "Error al eliminar socio: " . $stmt->error;
            }
            $stmt->close();
        }
    }

    $controlador = new eliminarSocio($conexion); 
    $controlador->eliminarSocio($email); 
    ?>
</body>
</html>
