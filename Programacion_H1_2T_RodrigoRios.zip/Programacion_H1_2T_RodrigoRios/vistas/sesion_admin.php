<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet"> 
<!-- Estilos estilos y más estilos -->
    <style>
        body, html {
    width: 100%;
    height: 100%;
    margin: 0;
    overflow: hidden; 
}
.container {
    width: 120%; 
    max-width: 1200px; 
    margin: 20px auto;
    padding: 20px;
    background-color: rgba(88, 100, 98, 0.9);
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
    overflow: hidden; 
}
.table-container {
    width: 100%;
    overflow-x: auto;
    overflow-y: auto; 
}
table {
    width: 100%; 
    border-collapse: collapse;
}
th, td {
    white-space: nowrap;  
    padding: 10px;
    text-align: center;
    border: 1px solid #ddd;
}
h2 {
    text-align: center;
    color: black;
    margin-bottom: 20px;
}

    h1, h2, p {
        text-align: center;
        color: black;
    }

    h1 {
        font-size: 2.5rem;
        font-weight: 600;
        margin-top: 20px;
    }

    .btn {
        background-color: rgb(9, 112, 229);
        color: white;
        border: none;
        padding: 8px 15px;
        font-size: 0.9rem;
        margin-top: 10px;
        border-radius: 5px;
    }

    .btn:hover {
        background-color: rgb(81, 242, 89);
    }

    .form-control, .form-select {
        margin-bottom: 15px;
    }

    .form-label {
        font-weight: bold;
    } 
</style>

    <title>Iniciar Sesión Admin</title>
</head>
<body>
    <div class="container">
        <?php
        session_start();
        require_once '../config/conexion.php';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $contraseña = ($_POST['contraseña']);
            // Comprobamos la contraseña
            
            if ($contraseña === "Admin123") {  
                // Una vez es correcta, se nos imprimen todo los datos de los usuarios
                $conexion = new Conexion(); 
                $conexion = $conexion->getConexion();

                $query = "
                    SELECT 
                        u.id, 
                        u.nombre_apellido, 
                        u.correo_email, 
                        u.edad, 
                        u.tipo_plan, 
                        u.fecha_registro, 
                        p.precio AS precio_plan_base, 
                        s.duracion, 
                        s.paquete_adicional, 
                        pa.precio AS precio_paquete 
                    FROM 
                        usuarios u
                    JOIN 
                        precios_planes p ON u.tipo_plan = p.tipo_plan
                    INNER JOIN 
                        subscripciones s ON u.id = s.usuario_id
                    INNER JOIN 
                        paquetes_adicionales pa ON s.paquete_adicional = pa.nombre
                ";

                $stmt = $conexion->prepare($query);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    echo "<div class='container'>";
                    echo "<h2 class='text-center'>Lista de Usuarios</h2>";
                    echo "<div class='table-container'>"; 
                    echo "<table class='table table-bordered'>";
                    echo "<thead class='thead-dark'>";
                    echo "<tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Correo</th>
                            <th>Edad</th>
                            <th>Plan</th>
                            <th>Precio del Plan</th>
                            <th>Fecha de Registro</th>
                            <th>Paquete Adicional</th>
                            <th>Duración</th>
                            <th>Precio del Paquete</th>
                        </tr>";
                    echo "</thead><tbody>";

// Los imprimimos con fetch_assoc()
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . ($row['id']) . "</td>";
                        echo "<td>" . ($row['nombre_apellido']) . "</td>";
                        echo "<td>" . ($row['correo_email']) . "</td>";
                        echo "<td>" . ($row['edad']) . " años</td>";
                        echo "<td>" . ($row['tipo_plan']) . "</td>";
                        echo "<td>" . ($row['precio_plan_base']) . " USD</td>";
                        echo "<td>" . ($row['fecha_registro']) . "</td>";
                        echo "<td>" . ($row['paquete_adicional']) . "</td>";
                        echo "<td>" . ($row['duracion']) . "</td>";
                        echo "<td>" . ($row['precio_paquete']) . " USD</td>";
                        echo "</tr>";
                    }
// Ponemos mensajes de aviso.
                    echo "</tbody></table>";
                    echo "<h2 class='text-center'>Para eliminar o modificar un usuario has de iniciar sesion con su correo electronico desde el inicio</h2>";
                    echo "<h4 class='text-center'>A fin de evitar posibles errores</h2>";
                    echo "<a class='btn btn-primary' href='index.html'>Volver a StreamWeb</a> ";
                    echo "</div>";
                } else {
                    echo "<div class='alert alert-warning'>No se encontraron usuarios.</div>";
                }
            } else {
                echo "<div class='alert alert-danger'>Contraseña incorrecta.</div>";
            }
        }
        ?>
</body>
</html>
