
<?php
// Empezamos con el session_start para obtener datos puestos anteriormente y que nos salgan en el formulario.
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['email'] = $_POST['email'];
    $_SESSION['nombre_apellido'] = $row['nombre_apellido'];
    $_SESSION['edad'] = $row['edad'];
    $_SESSION['tipo_plan'] = $row['tipo_plan'];
    $_SESSION['duracion'] = $row['duracion'];
    $_SESSION['paquete_adicional'] = $row['paquete_adicional'];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hito 2 Rodrigo Ríos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" defer></script>
</head>
<body>
    <!-- En el formulario accedemos a los valores si existen mediante el isset y si no hay datos estaria vacio, es como un if pero mas corto.-->
    <div class="container mt-5">
        <h1>Editar Usuario</h1>
        <form id="myForm" action="modificar_usuario.php" method="POST" class="p-4 shadow-sm bg-light rounded">
            <div class="mb-3">
                <label for="nombre_apellido" class="form-label">Nombre y apellidos:</label>
                <input type="text" id="nombre_apellido" name="nombre_apellido" class="form-control" value="<?php echo isset($_SESSION['nombre_apellido']) ? ($_SESSION['nombre_apellido']) : ''; ?>" require>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Correo electrónico:</label>
                <input type="email" id="email" name="email" class="form-control" value="<?php echo isset($_SESSION['email']) ? ($_SESSION['email']) : ''; ?>" readonly require>
            </div>
            <div class="mb-3">
                <label for="edad" class="form-label">Edad:</label>
                <input type="number" id="edad" name="edad" class="form-control" value="<?php echo isset($_SESSION['edad']) ? ($_SESSION['edad']) : ''; ?>" require>
            </div>
            <div class="mb-3">
                <label for="plan" class="form-label">Planes:</label>
                <select id="plan" name="plan" class="form-select" required>
                    <option value="">Selecciona tu plan</option>
                    <option value="Basico">Plan Básico (1 Dispositivo)</option>
                    <option value="Estandar">Plan Estandar (3 Dispositivos)</option>
                    <option value="Premium">Plan Premium (4 Dispositivos)</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="subscripcion" class="form-label">Subscripción:</label>
                <select id="subscripcion" name="subscripcion" class="form-select" required>
                    <option value="">Selecciona tu Subscripción</option>
                    <option value="Infantil">Infantil</option>
                    <option value="Deporte">Deporte</option>
                    <option value="Cine">Cine</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="duracion" class="form-label">Duración:</label>
                <select id="duracion" name="duracion" class="form-select" required>
                    <option value="">Selecciona como quieres que se haga la renovación</option>
                    <option value="Anual">Anual</option>
                    <option value="Mensual">Mensual</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Enviar</button>
        </form>
        <!-- Aqui introducimos el archivo de js en el que el código es igual que el del index pero solo tengo que vincularlo y no hacerlo otra vez. -->
    <script src="script_darse_alta.js" defer></script>
</body>
</html>
