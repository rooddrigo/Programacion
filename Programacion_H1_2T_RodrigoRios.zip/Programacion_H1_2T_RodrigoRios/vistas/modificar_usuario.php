<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        /* Estilos */
        body {
            background-image: url('fotofondo.png'); 
            background-size: cover; 
            background-position: center; 
            background-repeat: no-repeat; 
            color: white;
            font-family: 'Poppins', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        h1, h2, p {
            text-align: center;
            color: white;
        }
        h1 {
            font-size: 2.5rem;
            font-weight: 600;
            margin-top: 20px;
        }
        .container {
            background-color: rgba(88, 100, 98, 0.7);
            padding: 20px;
            border-radius: 8px;
            max-width: 600px;
            width: 100%;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
        }
        .result {
            margin-top: 30px;
            font-size: 1.2rem;
        }
        .btn {
            background-color:rgb(9, 112, 229);
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 1.1rem;
            margin-top: 20px;
            width: 100%;
            border-radius: 5px;
        }
        .btn:hover {
            background-color:rgb(81, 242, 89);
        }
    </style>
    <title>Modificar Socios</title>
</head>
<body>
    <div class="container">
        <?php
        require_once '../config/conexion.php';
// Comprobamos lo recibido
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre_apellido = htmlspecialchars($_POST['nombre_apellido']);
            $email = htmlspecialchars($_POST['email']);
            $edad = htmlspecialchars($_POST['edad']);
            $planes = htmlspecialchars($_POST['plan']);
            $subscripcion = htmlspecialchars($_POST['subscripcion']);
            $duracion = htmlspecialchars($_POST['duracion']);

            $conexion = new Conexion(); 
            $conexion = $conexion->getConexion();
// Volvemos a calcular los precios con las mismas clases.
            class precioPlanes {
                private $conexion;
                public function __construct($conexion) {
                    $this->conexion = $conexion;
                }

                public function obtenerPrecioPlan($planes) {
                    $query = "SELECT precio FROM precios_planes WHERE tipo_plan = '$planes'";
                    $resultado = $this->conexion->query($query);
                    if ($fila = $resultado->fetch_assoc()) {
                        return $fila['precio'];
                    }
                    return null;
                }
            }

            class precioSubscripciones {
                private $conexion;

                public function __construct($conexion) {
                    $this->conexion = $conexion;
                }

                public function obtenerPrecioSubscripciones($subscripcion) {
                    $query = "SELECT precio FROM paquetes_adicionales WHERE nombre = '$subscripcion'";
                    $resultado = $this->conexion->query($query);
                    if ($fila = $resultado->fetch_assoc()) {
                        return $fila['precio'];
                    }
                    return null;
                }
            }

            $precio_plan = new precioPlanes($conexion);
            $precio_subscripcion = new precioSubscripciones($conexion);
            $precio_del_plan = $precio_plan->obtenerPrecioPlan($planes);
            $precio_de_la_subscripcion = $precio_subscripcion->obtenerPrecioSubscripciones($subscripcion);

            echo "<p class='result'><strong>Precio del Plan:</strong> $precio_del_plan €</p>";
            echo "<p class='result'><strong>Precio de la Subscripción elegida:</strong> $precio_de_la_subscripcion €</p>";
            
            if ($duracion === 'Anual') {
                $precio_total = ($precio_del_plan + $precio_de_la_subscripcion) * 12;
            } else {
                $precio_total = $precio_del_plan + $precio_de_la_subscripcion;
            }

            echo "<p class='result'><strong>Precio total a pagar:</strong> $precio_total €</p>";

        } else {
            echo "<p>Por favor, envía el formulario correctamente.</p>";
        }
// Creamos la clase modificar socio donde lo modificará con un update
        class modificarSocio {
            private $conexion;

            public function __construct($conexion) {
                $this->conexion = $conexion;
            }

            public function modificarSocio($nombre_apellido, $email, $edad, $planes) {
                $query = "UPDATE usuarios SET nombre_apellido = ?, correo_email = ?, edad = ?, tipo_plan = ? WHERE correo_email = ?";
                $stmt = $this->conexion->prepare($query);
                
                $stmt->bind_param("ssiss", $nombre_apellido, $email, $edad, $planes, $email); 
                
                if ($stmt->execute()) {
                    echo '<h1>Socio actualizado con éxito</h1>';
                    $query2 = "SELECT id FROM usuarios WHERE correo_email = ?";
                    $stmt2 = $this->conexion->prepare($query2);
                    $stmt2->bind_param("s", $email); 
                    $stmt2->execute();
                    $result = $stmt2->get_result();
            
                    if ($row = $result->fetch_assoc()) {
                        $usuario_id = $row['id'];  
                        $stmt2->close();
                        return $usuario_id;  
                    } else {
                        echo "Algo ha fallado al obtener el ID";
                        $stmt2->close();
                    }
                } else {
                    echo "<h2>Error al agregar socio</h2>";
                }
                $stmt->close();
            }
        }
        $controller = new modificarSocio($conexion);
        $usuario_id = $controller->modificarSocio($nombre_apellido, $email, $edad, $planes);
// También modificamos la suscripción
        if ($usuario_id) {
            class modificarSubscripcion {
                private $conexion;
                
                public function __construct($conexion) {
                    $this->conexion = $conexion;
                }
        
                public function agregarSubscripcionSocio($usuario_id, $subscripcion, $planes, $duracion) {
                    $query3 = "UPDATE subscripciones SET paquete_adicional = ?, tipo_de_plan = ?, duracion = ? WHERE usuario_id = ?";
                    $stmt3 = $this->conexion->prepare($query3);
                    $stmt3->bind_param("sssi", $subscripcion, $planes, $duracion, $usuario_id);
                    $stmt3->execute();
                    if ($stmt3->affected_rows > 0) {
                        echo "<h1>Subscripción actualizada con éxito.</h1>";
                    } else {
                        echo "<h1>Hubo un error al actualizar la subscripción.</h1>";
                    }
                    $stmt3->close();
                }
            }
        
            $controlador = new modificarSubscripcion($conexion);
            $insertar_subscripcion = $controlador->agregarSubscripcionSocio($usuario_id, $subscripcion, $planes, $duracion);
        
        } else {
            echo "<h2>No se pudo obtener el ID del usuario, no se puede agregar la subscripción.</h2>";
        }
        ?>
        <a class="btn" href="index.html">Volver a StreamWeb</a>
    </div>
</body>
</html>
