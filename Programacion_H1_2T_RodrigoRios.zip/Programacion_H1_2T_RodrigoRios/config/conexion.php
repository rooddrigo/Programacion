<?php
class Conexion {
    private $conexion;

    public function __construct() {
        // Nos conectamos a la base de datos.
        $this->conexion = new mysqli("localhost", "root", "curso", "streamweb");
        // Verificamos si la conexión ha fallado.
        if ($this->conexion->connect_error) {
            die("Conexión fallida: " . $this->conexion->connect_error);
        }
    }
    // Método para poder usar la conexión desde otros archivos, la utilizaremos en todo el hito.
    public function getConexion() {
        return $this->conexion;
    }
}
?>
