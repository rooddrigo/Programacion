package paquetes;
//hacemos un extends de la clase abstracta.
class Gato extends Animal {
	// creamos el atributo adicional en private para que no se pueda acceder desde otra clase o subclase
	//y de tipo boolean ya que es si o no
    private boolean testLeucemia;
    //Hacemos el constructor de gato, por eso el mismo nombre de la clase para inicializar los atributos de la 
    //clase abstracta Animal
    public Gato(String chip, String nombre, int edad, String raza, boolean adoptado, boolean testLeucemia) {
        super(chip, nombre, edad, raza, adoptado);
        //inicializamos el atributo de leucemia
        this.testLeucemia = testLeucemia;
    }
    @Override
    //Override porque estamos sobreescribiendo el metodo de la clase abstracta y hacemos el mostrar con los datos.
    public void mostrar() {
        System.out.println("Animal: Gato || Chip: " + chip + " ||  Nombre: " + nombre + "||  Edad: " + edad + " || Raza: " + raza + "|| Adoptado: " + adoptado + " || Test Leucemia: " + testLeucemia);
    }
    //MODIFICADO DESPUÉS PARA PODER OBTENER LOS GATOS CON LEUCEMIA AL MOSTRARLOS TODOS
    public boolean getLeucemia() {
        return testLeucemia;
    }
}
