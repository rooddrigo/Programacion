package paquetes;
//importamos java util para poder usar hashmap y scanner.
import java.util.*;

//Creamos la clase Principal que contendrá los métodos y el hashmap
public class Principal {

//Creamos el hashmap de que tendra el chip de los animales como clave para poder buscarlos o introducir nuevos.
 static HashMap<String, Animal> animales = new HashMap<>();

 //CREAMOS EL METODO DEL MENÚ CON LAS OPCIONES
 public static void mostrarMenu() {
     System.out.println("\nMENÚ DEL HITO:");
     System.out.println("1 || Dar de alta algún animal");
     System.out.println("2 || Ver todos los animales");
     System.out.println("3 || Buscar algún animal por su chip");
     System.out.println("4 || Página de adopción");
     System.out.println("5 || Dar de baja algún animal");
     System.out.println("6 || Mostrar estadísticas de todos los gatos");
     System.out.println("0 || Salir");
     System.out.print("\nSelecciona una opción: ");
 }

//CREAMOS UN METODO PARA LISTAR LOS ANIMALES
 public static void listaDeAnimales() {
	 //VERIFICA QUE EL TAMAÑO DEL HASHMAP NO SEA 0, ES DECIR QUE AL MENOS HAYA UN ANIMAL
	    if (animales.size() == 0) {
	        System.out.println("No hay animales todavia.");
	    } else {
	    	//LO IMPRIMOS CON UN FOREACH, ACCEDIENDO A ELLOS MEDIANTE EL .values
	        for (Animal animal : animales.values()) {
	            animal.mostrar();
	        }
	    }
	}
 
 //ESTE ES EL METODO QUE CUENTA EL NÚMERO DE GATOS Y LOS QUE TIENEN LEUCEMIA.
 public static void estatsGatos() {
     int totalGatos = 0;
     int gatosLeucemia = 0;
     for (Animal animal : animales.values()) {
    	 //PARA VERIFICAR QUE EL ANIMAL SEA UN GATO, MEDIANTE INSTANCEOF, QUE DEVUELVE UN TRUE AL RECORRER EL
    	 //HASHMAP Y ENCONTRARSE CON UN GATO, POR ESO LUEGO SUMAMOS UNO AL CONTADOR.
         if (animal instanceof Gato) {
             totalGatos++;
             //PARA OBTENER LOS GATOS CON LEUCEMIA, USAMOS EL GET.
             if (((Gato) animal).getLeucemia()) {
                 gatosLeucemia++;
             }
         }
     }
     System.out.println("El número total de gatos es de: " + totalGatos);
     System.out.println("El número total de gatos con leucemia es: " + gatosLeucemia);
 }
 
 //PARA BUSCAR ANIMALES, SIMPLEMENTE HEMOS AÑADIDO LA OPCIÓN DE INTRODUCIR EL CHIP DESDE AQUI Y NO DESDE EL MENÚ.
 public static void buscarAnimal(Scanner sc) {
     System.out.print("Introduce el chip del animal: ");
     String chip = sc.nextLine();
     Animal animal = animales.get(chip);
     if (animal != null) {
         animal.mostrar();
     } else {
         System.out.println("No se existe ese chip.");
     }
 }
 
 //PARA DAR DE DE BAJA, HACEMOS LO MISMO QUE PARA BUSCARLO, PERO AÑADIMOS UN REMOVE CON ESE CHIP
 public static void darDeBaja(Scanner sc) {
     System.out.print("Introduce el chip del animal que quieras dar de baja: ");
     String chip = sc.nextLine();
     Animal animal = animales.get(chip);
     //VERIFICAMOS SI EL CHIP EXISTE.
     if (animal == null) {
         System.out.println("No se encontró ese chip.");
     } else {
         animales.remove(chip);
         System.out.println("El animal con chip " + chip + " nos ha dejado :(");
     }
 }
 
 //PARA PODER ADOPTAR ANIMALES, PEDIMOS EL CHIP
 public static void realizarAdopcion(Scanner sc) {
	    System.out.print("Introduce el chip del animal que vas a adoptar: ");
	    String chip = sc.nextLine();
	    Animal animal = animales.get(chip);
	    
	    //COMPROBAMOS QUE EL CHIP EXISTA Y QUE NO ESTÉ ADOPTADO MEDIANTE EL GET.
	    if (animal == null) {
	        System.out.println("No se encontró el animal con ese chip.");
	    } else if (animal.getAdoptado()) {
	        System.out.println("El animal ya ha sido adoptado.");
	    } else {
	    	
	    	//UNA VEZ COMPROBADO LO ANTERIOR, PEDIMOS LOS DATOS DE LA PERSONA.
	        System.out.print("Introduce el nombre de la persona que adopta: ");
	        String nombreAdoptante = sc.nextLine();
	        System.out.print("Introduce el DNI de la persona que adopta: ");
	        String dniAdoptante = sc.nextLine();
	        // CREAMOS UN OBJETO DE LA CLASE ADOPTAR
	        AdoptarAnimal adopcion = new AdoptarAnimal(chip, nombreAdoptante, dniAdoptante);
	        // PARA CAMBIAR EL ESTADO DEL ANIMAL, UTILIZAMOS UN SET.
	        animal.setAdoptado(true);
	        //MOSTRAMOS UNA CONFIRMACIÓN
	        adopcion.mostrar();
	    }
	}

 //CREAMOS EL MENÚ PRINCIPAL CON TODAS LAS OPCIONES.
 
 public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    //CREAMOS LA VARIABLE DE OPCION.
	    int opcion = 0;
//HE USADO UN DO WHILE PARA QUE SI O SI SE MUESTRE EL MENÚ, HASTA QUE EL USUARIO QUIERA.
	    do {
	    	//LLAMAMOS AL MENÚ
	        mostrarMenu();
	        try {
	        	//USAMOS UN TRY PARA CONTROLAR ERRORES.
	        	//EL PARSEINT LO USAMOS PARA QUE CAMBIE EL STRING EN UN INT, YA QUE EL SCANNER TODO LO CONVIERTE
	        	//EN UN STRING
	            opcion = Integer.parseInt(sc.nextLine());
	            //LLAMAMOS A LAS DISTINTAS OPCIONES, ALGUNAS TIENEN ARGUMENTO, DEPENDIENDO SI TIENEN QUE 
	            //INTRODUCIR DATOS O NO.
	            if (opcion == 1) {
	                AltaAnimal.darAlta(animales, sc); 
	            } else if (opcion == 2) {
	                listaDeAnimales();
	            } else if (opcion == 3) {
	                buscarAnimal(sc); 
	            } else if (opcion == 4) {
	                realizarAdopcion(sc); 
	            } else if (opcion == 5) {
	                darDeBaja(sc); 
	            } else if (opcion == 6) {
	                estatsGatos();
	            } else if (opcion == 0) {
	            	//HACEMOS QUE AL MARCAR EL NÚMERO 0 SE SALGA
	                System.out.println("Hasta luego Lucas...");
	            } else {
	            	//EN CASO DE PONER UN NÚMERO NO VÁLIDO.
	                System.out.println("Opción no válida. Inténtalo de nuevo con las opciones que ves ahí.");
	            }
	            //EN CASO DE ESCRIBIR ALGO QUE NO SEA UN NUMERO.
	        } catch (NumberFormatException e) {
	            System.out.println("Entrada inválida. Tienes que poner un número.");
	        }

	    } while (opcion != 0); 
	
     sc.close(); // CERRAMOS EL SCANNER FUERA PARA QUE SIEMPRE SE CIERRE.
 }
}
