package paquetes;

//CREAMOS LOS ATRIBUTOS
public class AdoptarAnimal {
	private String chip;
	private String nombrePersona;
	private String dni;
	//HACEMOS UN CONSTRUCT PARA INICIALIZAR LAS VARIABLES.
	public AdoptarAnimal(String chip, String nombrePersona, String dni) {
		this.chip = chip;
		this.nombrePersona = nombrePersona;
		this.dni = dni;
	}
	//HACEMOS UN GETCHIP, NOMBRE Y DNI PARA PODER USARLO FUERA
	public String getChip() {
		return chip;
	}
	public String getNombrePersona() {
		return nombrePersona;
	}
	public String getDni() {
		return dni;
	}
	//SOBREESCRIBIMOS MOSTRAR PARA HACER UN MENSAJE DE CONFIRMACIÓN.
	 public void mostrar() {
	        System.out.println("Chip del animal: " + chip + " fue adoptado por " +
	                           nombrePersona + " con DNI: " + dni);
	    }
	}

