package paquetes;

//IMPORTAMOS EL JAVA UTIL PARA USAR UN HASHMAP
import java.util.*;
public class AltaAnimal {

    public static void darAlta(HashMap<String, Animal> animales, Scanner sc) {
//COMPROBAMOS QUE ANIMAL VA A INTRODUCIR, SU CIP, NOMBRE, ETC.
        System.out.print("¿Qué animal vas a introducir, gato o perro? ");
        String tipo = sc.nextLine();

        System.out.print("Chip: ");
        String chip = sc.nextLine();
        
        if (animales.get(chip) != null) {
            System.out.println("Elige otro chip, ese ya existe.");
            return;
        } else {
        	System.out.print("Nombre: ");
            String nombre = sc.nextLine();
            
            System.out.print("Raza: ");
            String raza = sc.nextLine();
            
            System.out.print("Edad: ");
            int edad = Integer.parseInt(sc.nextLine());
         
            if (tipo.equals("perro")) {
            	//PREGUNTAMOS EL TAMAÑO Y EL TEST DE LEUCEMIA
                System.out.print("Tamaño (Grande/Mediano/Pequeño): ");
                String tamaño = sc.nextLine();
//CREAMOS UN OBJETO NUEVO PARA CADA ANIMAL, INTRODUCIENDO SUS DATOS COMO ARGUMENTO.
            Animal nuevoAnimal = new Perro(chip, nombre, edad, raza, false, tamaño);
            animales.put(chip, nuevoAnimal);
            } else if (tipo.equals("gato")) {
            System.out.print("¿Tiene test de leucemia positivo? (true/false): ");
            boolean leucemia = Boolean.parseBoolean(sc.nextLine());
            Animal nuevoAnimal = new Gato(chip, nombre, edad, raza, false, leucemia);
            animales.put(chip, nuevoAnimal);

          
            }
}
    }}