package paquetes;
//creamos la clase abstracta de animal que contiene los atributos principales de los animales
public abstract class Animal {
 protected String chip;
 protected String nombre;
 protected int edad;
 protected String raza;
 protected boolean adoptado;

 //hacemos el construct para inicializar los atributos.
 public Animal(String chip, String nombre, int edad, String raza, boolean adoptado) {
     this.chip = chip;
     this.nombre = nombre;
     this.edad = edad;
     this.raza = raza;
     this.adoptado = adoptado;
 }
//creamos el método mostrar que luego sobreescribiremos.
 public abstract void mostrar();
//también el método para poder obtener el chip de los animales.
 public String getChip() {
     return chip;
}
 //HEMOS AÑADIDO UN GET Y UN SET PARA PODER OBTENER Y MODIFICAR EL ESTADO DEL ANIMAL
 public boolean getAdoptado() {
	 return adoptado;
 }
 public void setAdoptado(boolean adoptado) {
     this.adoptado = adoptado;
 }
}

