import java.util.Scanner;
public class SumaNumerosDoWhile {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int suma = 0, num;
        do {
            System.out.print("Ingrese un número (0 para salir): ");
            num = scanner.nextInt();
            suma += num; 
        } while (num != 0); 
        System.out.println("La suma total es: " + suma);
    }
}
