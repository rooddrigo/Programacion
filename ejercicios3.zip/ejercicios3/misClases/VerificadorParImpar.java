package misClases;
public class VerificadorParImpar {
    public static boolean esPositivoYPar(int numero) {
        return numero > 0 && numero % 2 == 0;    }
}
