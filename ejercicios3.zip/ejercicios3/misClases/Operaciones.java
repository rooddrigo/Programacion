package misClases;
public class Operaciones {
    int num1 = 4;
    int num2 = 2;
    int resultado;
    public void realizarOperaciones() {
        resultado = num1 + num2;
        System.out.println("La suma da: " + resultado);
        resultado = num1 - num2;
        System.out.println("La resta da: " + resultado);
        resultado = num1 * num2;
        System.out.println("El producto da: " + resultado);
        resultado = num1 / num2;
        System.out.println("El cociente da: " + resultado);
    }
}
