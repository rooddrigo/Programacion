package misClases;
public class Comparador {
    public void comparar(int a, int b) {
        if (a > b) {
            System.out.println(a + " es mayor que " + b);
        } else if (a < b) {
            System.out.println(b + " es mayor que " + a);
        } else {
            System.out.println("Son iguales");}
    }
}
