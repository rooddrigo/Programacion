import misClases.Comparador;
public class ComparadorPrincipal {
    public static void main(String[] args) {
        Comparador comparar = new Comparador();
        comparar.comparar(4, 2);
        comparar.comparar(2, 4);
        comparar.comparar(4, 4);
    }
}
