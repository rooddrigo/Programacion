import misClases.Operaciones;
public class OperacionesPrincipal {
    public static void main(String[] args) {
        Operaciones operacion = new Operaciones();
        operacion.realizarOperaciones();
    }
}
