import misClases.VerificadorParImpar;
public class VerificadorPrincipal {
    public static void main(String[] args) {
        System.out.println(VerificadorParImpar.esPositivoYPar(2)); 
        System.out.println(VerificadorParImpar.esPositivoYPar(-2)); 
        System.out.println(VerificadorParImpar.esPositivoYPar(1)); 
    }
}
