public class CuentaRegresiva {
    public static void main(String[] args) {
        int i = 10; // Comienza en 10
        while (i >= 1) { 
            System.out.println(i);
            i--;
        }
    }
}
