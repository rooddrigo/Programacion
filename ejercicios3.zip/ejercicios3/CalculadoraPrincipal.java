import misClases.Calculadora;
public class CalculadoraPrincipal {
    public static void main(String[] args) {
       Calculadora calculo = new Calculadora();
       System.out.println(calculo.doble(5));
       System.out.println(calculo.doble(10));
         System.out.println(calculo.doble(15));
    }
}
