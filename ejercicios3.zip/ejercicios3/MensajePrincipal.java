import misClases.Mensaje;
public class MensajePrincipal {
    public static void main(String[] args) {
        Mensaje mensaje = new Mensaje();
        mensaje.mostrarMensaje();
    }
}
