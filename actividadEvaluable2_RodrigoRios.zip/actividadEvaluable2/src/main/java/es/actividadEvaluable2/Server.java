package es.actividadEvaluable2;

import java.io.*;
import java.net.*;
import java.util.List;

public class Server {
    private static final int PORT = 5000;

    public static void main(String[] args) {
        DatabaseManager db = new DatabaseManager();

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Servidor iniciado en el puerto " + PORT);

            // Bucle infinito: acepta múltiples clientes
            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("Cliente conectado desde: " + socket.getInetAddress());

                // Cada cliente se maneja en un hilo separado
                new Thread(new ClientHandler(socket, db)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

// Clase interna para manejar cada cliente en un hilo separado
class ClientHandler implements Runnable {
    private final Socket socket;
    private final DatabaseManager db;

    public ClientHandler(Socket socket, DatabaseManager db) {
        this.socket = socket;
        this.db = db;
    }

    @Override
    public void run() {
        try (
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true)
        ) {
            out.println("Conexión establecida con el servidor.");
            out.println("Comandos disponibles:");
            out.println("1) titulo:<palabra> → Buscar libros por título");
            out.println("2) autor:<nombre> → Buscar libros por autor");

            String mensaje;
            while ((mensaje = in.readLine()) != null) {
                System.out.println("Cliente dice: " + mensaje);
                if (mensaje.equalsIgnoreCase("salir")) break;

                if (mensaje.startsWith("titulo:")) {
                    String keyword = mensaje.substring(7).trim();
                    List<String> resultados = db.buscarPorTitulo(keyword);
                    enviarResultados(out, resultados);
                } else if (mensaje.startsWith("autor:")) {
                    String autor = mensaje.substring(6).trim();
                    List<String> resultados = db.buscarPorAutor(autor);
                    enviarResultados(out, resultados);
                } else {
                    out.println("Comando no reconocido. Usa 'titulo:<palabra>' o 'autor:<nombre>'.");
                }
            }

            socket.close();
            System.out.println("Cliente desconectado.");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void enviarResultados(PrintWriter out, List<String> resultados) {
        if (resultados.isEmpty()) {
            out.println("No se encontraron resultados.");
        } else {
            out.println("Resultados encontrados:");
            for (String linea : resultados) {
                out.println(" - " + linea);
            }
        }
        out.println("--- Fin de resultados ---");
    }
}
