package es.actividadEvaluable2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    private static final String SERVER_IP = "localhost";
    private static final int SERVER_PORT = 5000;

    public static void main(String[] args) {
        try (
                Socket socket = new Socket(SERVER_IP, SERVER_PORT);
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                Scanner scanner = new Scanner(System.in)
        ) {
            System.out.println("Conectado al servidor en " + SERVER_IP + ":" + SERVER_PORT);

            // Mensajes iniciales del servidor
            String linea;
            while ((linea = in.readLine()) != null) {
                System.out.println(linea);
                if (linea.contains("Comandos disponibles:")) break; // dejamos de leer el bloque inicial
            }

            // Bucle de comunicación con el servidor
            while (true) {
                System.out.print("\nIntroduce comando (ej: titulo:java / autor:ana / salir): ");
                String mensaje = scanner.nextLine();
                out.println(mensaje);

                if (mensaje.equalsIgnoreCase("salir")) {
                    System.out.println("Cerrando conexión...");
                    break;
                }

                // Leer la respuesta del servidor
                while ((linea = in.readLine()) != null) {
                    if (linea.equals("--- Fin de resultados ---") || linea.contains("Comando no reconocido")) {
                        System.out.println(linea);
                        break;
                    }
                    System.out.println(linea);
                }
            }

        } catch (IOException e) {
            System.err.println("Error en la conexión con el servidor: " + e.getMessage());
        }
    }
}
