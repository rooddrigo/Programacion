package es.actividadEvaluable2;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseManager {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/gestor_examenes?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASS = "curso";

    public Connection connect() throws SQLException {
        return DriverManager.getConnection(DB_URL, USER, PASS);
    }

    // Buscar libros por palabra clave en el título
    public List<String> buscarPorTitulo(String keyword) {
        List<String> resultados = new ArrayList<>();
        String query = "SELECT title, author, genre, year FROM books WHERE title LIKE ?";

        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, "%" + keyword + "%");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String linea = String.format(
                        "%s (%s, %s, %d)",
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getString("genre"),
                        rs.getInt("year")
                );
                resultados.add(linea);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return resultados;
    }

    // Buscar libros por autor
    public List<String> buscarPorAutor(String autor) {
        List<String> resultados = new ArrayList<>();
        String query = "SELECT title, genre, year FROM books WHERE author LIKE ?";

        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, "%" + autor + "%");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String linea = String.format(
                        "%s (%s, %d)",
                        rs.getString("title"),
                        rs.getString("genre"),
                        rs.getInt("year")
                );
                resultados.add(linea);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return resultados;
    }
}
