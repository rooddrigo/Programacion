    package gestor;

    import java.io.*;
    import java.net.*;
    import java.util.List;
    import java.util.concurrent.ExecutorService;
    import java.util.concurrent.Executors;

    /**
     * Servidor multicliente que atiende solicitudes de búsqueda de libros.
     */
    public class Server {
        // Puerto de escucha
        private static final int PORT = 5555;

        // URL de conexión MySQL (ajusta usuario y contraseña a los tuyos)
        private static final String DB_URL = "jdbc:mysql://localhost:3306/gestor_examenes?useSSL=false&serverTimezone=UTC";
        private static final String USER = "root"; //
        private static final String PASS = "curso";     //
        public static void main(String[] args) {
            DataAccess dataAccess = new DataAccess(DB_URL, USER, PASS);
            ExecutorService pool = Executors.newFixedThreadPool(10); // hasta 10 clientes simultáneos

            try (ServerSocket serverSocket = new ServerSocket(PORT)) {
                System.out.println("✅ Servidor arrancado en puerto " + PORT);

                while (true) {
                    Socket clientSocket = serverSocket.accept();
                    System.out.println("🔗 Conexión desde " + clientSocket.getInetAddress());
                    pool.execute(() -> handleClient(clientSocket, dataAccess));
                }

            } catch (IOException e) {
                System.err.println(" Error en el servidor: " + e.getMessage());
            }
        }

        /**
         * Atiende a un cliente individual.
         */
        private static void handleClient(Socket clientSocket, DataAccess dataAccess) {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                 PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {

                out.println("Conectado al servidor. Usa el formato:");
                out.println("MODE:title|author|genre  QUERY:palabra");
                out.println("Ejemplo -> MODE:author QUERY:Ana");

                String input;
                while ((input = in.readLine()) != null) {
                    System.out.println("📩 Petición recibida: " + input);

                    if (input.equalsIgnoreCase("exit")) break;

                    // Parsear el mensaje del cliente
                    String[] parts = input.split("QUERY:");
                    if (parts.length < 2) {
                        out.println(" Formato inválido. Usa: MODE:author QUERY:Ana");
                        continue;
                    }

                    String mode = parts[0].replace("MODE:", "").trim();
                    String query = parts[1].trim();

                    // Consultar base de datos
                    List<Book> results = dataAccess.search(mode, query);

                    // Enviar resultados
                    if (results.isEmpty()) {
                        out.println("No se encontraron resultados.");
                    } else {
                        for (Book book : results) {
                            out.println(book.toString());
                        }
                    }
                    out.println("Fin de la respuesta.");
                }

                System.out.println("❎ Cliente desconectado.");
                clientSocket.close();

            } catch (IOException e) {
                System.err.println(" Error con cliente: " + e.getMessage());
            }
        }
    }
