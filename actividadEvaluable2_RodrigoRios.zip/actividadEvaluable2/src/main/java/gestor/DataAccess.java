package gestor;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Capa de acceso a datos: maneja la conexión y consultas a la base de datos MySQL.
 */
public class DataAccess {
    private String dbUrl;
    private String user;
    private String pass;

    public DataAccess(String dbUrl, String user, String pass) {
        this.dbUrl = dbUrl;
        this.user = user;
        this.pass = pass;
    }

    public List<Book> search(String mode, String query) {
        List<Book> results = new ArrayList<>();
        String sql = "SELECT * FROM books WHERE " + mode + " LIKE ?";

        try (Connection conn = DriverManager.getConnection(dbUrl, user, pass);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, "%" + query + "%");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                results.add(new Book(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getString("genre"),
                        rs.getInt("year"),
                        rs.getString("description")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error en la búsqueda: " + e.getMessage());
        }

        return results;
    }
}
