package gestor;
/**
 * Clase modelo que representa un libro.
 */
public class Book {
    private int id;
    private String title;
    private String author;
    private String genre;
    private int year;
    private String description;

    public Book(int id, String title, String author, String genre, int year, String description) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.year = year;
        this.description = description;
    }

    // Getters
    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public String getGenre() { return genre; }
    public int getYear() { return year; }
    public String getDescription() { return description; }

    // Representación en una línea para enviar al cliente (campos separados por '|')
    @Override
    public String toString() {
        return id + "|" + title + "|" + author + "|" + genre + "|" + year + "|" + description;
    }
}
