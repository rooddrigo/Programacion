public class ProductorExamenes implements Runnable {
    private static int contador = 0;
    private final BufferExamenes buffer;
    private final Thread hilo;

    public ProductorExamenes(BufferExamenes buffer) {
        this.buffer = buffer;
        contador++;
        this.hilo = new Thread(this, "E" + contador);
    }

    public void iniciar() {
        hilo.start();
    }

    @Override
    public void run() {
        int año = java.time.LocalDateTime.now().getYear();
        String codigo = hilo.getName() + "-" + año;
        buffer.fabricarNuevoExamen(codigo);
        System.out.println("Producido examen " + codigo);
    }
}
