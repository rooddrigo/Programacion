public class Principal {
    public static void main(String[] args) {
        BufferExamenes buffer = new BufferExamenes();

        String[] alumnos;
        if (args.length > 0)
            alumnos = args;
        else
            alumnos = new String[]{"Rosa", "Miguel", "Carlos"};

                ProductorExamenes[] productores = new ProductorExamenes[alumnos.length];
        Examinador[] examinadores = new Examinador[alumnos.length];

        for (int i = 0; i < alumnos.length; i++) {
            productores[i] = new ProductorExamenes(buffer);
        }

        for (int i = 0; i < alumnos.length; i++) {
            examinadores[i] = new Examinador(alumnos[i], buffer);
        }

        // Ahora sí, arrancamos los hilos explícitamente:
        for (ProductorExamenes p : productores) p.iniciar();
        for (Examinador e : examinadores) e.iniciar();

    }
}
