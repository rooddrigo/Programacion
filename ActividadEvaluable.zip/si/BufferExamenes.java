import java.util.*;


public class BufferExamenes {
    private final Queue<String> cola = new LinkedList<>();

    public synchronized void fabricarNuevoExamen(String codigo) {
        cola.add(codigo);
        notifyAll(); // avisar a los consumidores
    }

    public synchronized String consumirExamen() {
        while (cola.isEmpty()) {
            try {
                wait();
            } catch (InterruptedException e) {
                return null;
            }
        }
        return cola.poll();
    }
}
