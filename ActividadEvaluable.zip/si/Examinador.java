import java.util.Random;

public class Examinador implements Runnable {
    private final BufferExamenes buffer;
    private final Thread hilo;
    private final Random random = new Random();

    public Examinador(String nombre, BufferExamenes buffer) {
        this.buffer = buffer;
        this.hilo = new Thread(this, nombre);
    }

    // Método separado para iniciar el hilo (evita el warning en el constructor)
    public void iniciar() {
        hilo.start();
    }

    @Override
    public void run() {
        String codigo = buffer.consumirExamen();
        if (codigo == null) return;

        String[] respuestas = {"A", "B", "C", "D", "-"};
        for (int i = 1; i <= 10; i++) {
            String r = respuestas[random.nextInt(respuestas.length)];
            System.out.println(codigo + ";" + hilo.getName() + "; Pregunta " + i + ";" + r);
            pausa(); // pausa breve entre preguntas
        }
    }

    // Método auxiliar para dormir el hilo (evita el warning por sleep en el bucle)
    private void pausa() {
        try {
            Thread.sleep(50);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
