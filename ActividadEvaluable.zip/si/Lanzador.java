import java.io.*;

public class Lanzador {
    public static void main(String[] args) throws IOException, InterruptedException {
        String javaBin = System.getProperty("java.home") + File.separator + "bin" + File.separator + "java";

        ProcessBuilder p1 = new ProcessBuilder(javaBin, "Principal", "Pepe", "Juan", "Luis");
        p1.redirectOutput(new File("examen1.txt"));
        ProcessBuilder p2 = new ProcessBuilder(javaBin, "Principal", "Rosa", "Miguel", "Pedro");
        p2.redirectOutput(new File("examen2.txt"));

        Process proc1 = p1.start();
        Process proc2 = p2.start();

        System.out.println("Lanzados los dos exámenes...");
        proc1.waitFor();
        proc2.waitFor();
        System.out.println("Finalizado. Archivos generados: examen1.txt y examen2.txt");
    }
}
