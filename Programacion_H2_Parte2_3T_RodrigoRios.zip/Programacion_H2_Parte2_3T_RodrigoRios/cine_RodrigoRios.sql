DROP DATABASE IF EXISTS cine;
CREATE DATABASE cine;
USE cine;

CREATE TABLE Pelicula (
    idPeli VARCHAR(10) PRIMARY KEY,
    titulo VARCHAR(100) NOT NULL,
    director VARCHAR(100),
    duracion INT,
    clasificacion VARCHAR(10),
    idiomaOriginal VARCHAR(50)
);

CREATE TABLE Genero (
    idGenero INT AUTO_INCREMENT PRIMARY KEY,
    nombreGenero VARCHAR(50) NOT NULL
);

CREATE TABLE Pelicula_Genero (
    idPeli VARCHAR(10),
    idGenero INT,
    PRIMARY KEY (idPeli, idGenero),
    FOREIGN KEY (idPeli) REFERENCES Pelicula(idPeli),
    FOREIGN KEY (idGenero) REFERENCES Genero(idGenero)
);
INSERT INTO Pelicula VALUES
('001', 'Interstellar', 'Christopher Nolan', 169, '12+', 'Inglés'),
('002', 'Oppenheimer', 'Christopher Nolan', 180, '12', 'Inglés'),
('003', 'The Dark Knight', 'Christopher Nolan', 152, '16+', 'Inglés'),
('004', 'Dunkirk', 'Christopher Nolan', 106, '12+', 'Inglés');
INSERT INTO Genero (nombreGenero) VALUES
('Acción'),
('Comedia'),
('Suspense'),
('Aventura'),
('Ciencia ficción');
INSERT INTO Pelicula_Genero (idPeli, idGenero) VALUES
('001', 5), 
('002', 2), 
('003', 4), 
('004', 1);
