package paquete;

// importamos java sql y java util para poder usar el scanner
import java.sql.*;
import java.util.*;

// Creamos la clase principal
public class Principal {
    public static void main(String[] args) {
        // Datos de conexión de mi base de datos "cine"
        String url = "jdbc:mysql://localhost:3306/cine";
        String usuario = "root";
        String contraseña = "curso"; 
        // Creamos la variable opción siendo un int para el usuario.
        Scanner scanner = new Scanner(System.in);
        int opcion;
        
        // Usamos un do while para asi asegurarnos de que al menos se ejecute una vez el programa
        do {
            // Llamamos al método mostrar menu.
            mostrarMenu();
            try {
                System.out.print("Selecciona una opción: ");
                opcion = Integer.parseInt(scanner.nextLine());

                switch (opcion) {
                //Llamamos a un método u otro en función de lo que elija.
                    case 1:
                        mostrarPeliculas(url, usuario, contraseña);
                        break;
                    case 2:
                        añadirPelicula(url, usuario, contraseña, scanner);
                        break;
                    case 3:
                        eliminarPelicula(url, usuario, contraseña, scanner);
                        break;
                    case 4:
                        modificarPelicula(url, usuario, contraseña, scanner);
                        break;
                    case 5:
                        System.out.println("¡Hasta luego!");
                        break;
                    default:
                        // Controlamos que no funciona otra opción
                        System.out.println("Opción no válida. Intenta de nuevo.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Por favor, ingresa un número válido.");
                opcion = 0; // Repetimos el menú
            }

        } while (opcion != 5); // El bucle se repite hasta que el usuario seleccione "Salir"

        scanner.close(); // Cerramos el escáner
    }

    // Método de mostrar menu con las opciones
    public static void mostrarMenu() {
        System.out.println("\n----- MENÚ -----");
        System.out.println("1 - Ver películas");
        System.out.println("2 - Añadir película");
        System.out.println("3 - Eliminar película");
        System.out.println("4 - Modificar película");
        System.out.println("5 - Salir");
    }

    // Mostrar las películas con sus géneros
    public static void mostrarPeliculas(String url, String usuario, String contraseña) {
        try {
            // Establecemos la conexión con la base de datos
            Connection conexion = DriverManager.getConnection(url, usuario, contraseña);
            Statement stmt = conexion.createStatement();
            
            // Consulta SQL para obtener todas las películas con sus géneros haciendo un join.
            String consultaPeliculas = "SELECT p.idPeli, p.titulo, p.director, p.duracion, p.clasificacion, p.idiomaOriginal, g.nombreGenero " +
                                       "FROM Pelicula p " +
                                       "JOIN Pelicula_Genero pg ON p.idPeli = pg.idPeli " +
                                       "JOIN Genero g ON pg.idGenero = g.idGenero";
            
            ResultSet rs = stmt.executeQuery(consultaPeliculas);
            System.out.println("\nCartelera\n");

            // Mostramos los resultados con un while los resultados
            while (rs.next()) {
                System.out.println("ID: " + rs.getString("idPeli"));
                System.out.println("Título: " + rs.getString("titulo"));
                System.out.println("Director: " + rs.getString("director"));
                System.out.println("Duración: " + rs.getInt("duracion") + " minutos");
                System.out.println("Clasificación de edad: " + rs.getString("clasificacion"));
                System.out.println("Idioma original: " + rs.getString("idiomaOriginal"));
                System.out.println("Género: " + rs.getString("nombreGenero"));
                System.out.println("\n");
            }
            // Cerramos el rs y el catch para las excepciones
            rs.close();
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    //creamos el método de añadir pelis.
    public static void añadirPelicula(String url, String usuario, String contraseña, Scanner scanner) {
        try {
            //Establecemos la conexión con la base de datos
            Connection conexion = DriverManager.getConnection(url, usuario, contraseña);

            System.out.println("Introduce el ID de la película:");
            String id = scanner.nextLine();
            System.out.println("Introduce el título de la película:");
            String titulo = scanner.nextLine();
            System.out.println("Introduce el director de la película:");
            String director = scanner.nextLine();
            System.out.println("Introduce la duración de la película (en minutos):");
            int duracion = Integer.parseInt(scanner.nextLine());
            System.out.println("Introduce la clasificación de la película:");
            String clasificacion = scanner.nextLine();
            System.out.println("Introduce el idioma original de la película:");
            String idioma = scanner.nextLine();

            // Pedimos al usuario que introduzca el id del genero nuevo. 
            //Esto es necesario porque si no, al hacer el select para ver las pelis, no me salian algunas.
            System.out.println("Introduce el ID del género de la película siendo 1- Acción, 2- Comedia, 3- Suspense, 4- Aventura, 5- Ciencia ficción:");
            String idGenero = scanner.nextLine();

            // Preparamos para insertar la película
            String sql = "INSERT INTO Pelicula (idPeli, titulo, director, duracion, clasificacion, idiomaOriginal) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conexion.prepareStatement(sql);
            pstmt.setString(1, id);
            pstmt.setString(2, titulo);
            pstmt.setString(3, director);
            pstmt.setInt(4, duracion);
            pstmt.setString(5, clasificacion);
            pstmt.setString(6, idioma);
            // Ejecutamos la consulta 
            pstmt.executeUpdate();  

            // Ahora preparamos un insert para añadir su género también
            String sqlGenero = "INSERT INTO Pelicula_Genero (idPeli, idGenero) VALUES (?, ?)";
            PreparedStatement pstmtGenero = conexion.prepareStatement(sqlGenero);
            pstmtGenero.setString(1, id);
            pstmtGenero.setString(2, idGenero);
            
            // Ejecutamos la consulta
            pstmtGenero.executeUpdate();  
            pstmt.close();
            pstmtGenero.close();
            conexion.close();

            System.out.println("Película añadida correctamente con su género.");
        } catch (SQLException e) {
        	//comprobamos si ha habido un error.
            System.out.println("Error al añadir la película: " + e.getMessage());
        }
    }
    
    //Creamos el método de eliminar.
    public static void eliminarPelicula(String url, String usuario, String contraseña, Scanner scanner) {
        try {
            Connection conexion = DriverManager.getConnection(url, usuario, contraseña);
            //Pedimos el id para asegurarnos que se borre unicamente la deseada.
            System.out.println("Introduce el ID de la película a eliminar:");
            String id = scanner.nextLine();

            // primero eliminamos de la tabla de genero para que no haya errores de integridad referencial.
            String sqlGenero = "DELETE FROM Pelicula_Genero WHERE idPeli = ?";
            PreparedStatement pstmtGenero = conexion.prepareStatement(sqlGenero);
            pstmtGenero.setString(1, id);
            pstmtGenero.executeUpdate();
            pstmtGenero.close();

            // Ahora si podemos eliminar la pelicula sin problemas.
            String sqlPelicula = "DELETE FROM Pelicula WHERE idPeli = ?";
            PreparedStatement pstmtPelicula = conexion.prepareStatement(sqlPelicula);
            pstmtPelicula.setString(1, id);
            int filasAfectadas = pstmtPelicula.executeUpdate();
            
            if (filasAfectadas > 0) {
                System.out.println("Película eliminada correctamente.");
            } else {
                System.out.println("No se encontró ninguna película con ese ID.");
            }

            pstmtPelicula.close();
            conexion.close();
            //cerramos conexiones y controlamos errores.
        } catch (SQLException e) {
            System.out.println("Error al eliminar la película: " + e.getMessage());
        }
    }
    //Por último creamos el método de modificar pelis
    public static void modificarPelicula(String url, String usuario, String contraseña, Scanner scanner) {
        try {
        	//Nos conectamos a la base de datos
            Connection conexion = DriverManager.getConnection(url, usuario, contraseña);

            //pedimos el id al usuario.
            System.out.println("Introduce el ID de la película a modificar:");
            String id = scanner.nextLine();
//he elegido que se pueda cambiar el título y el director.
            System.out.println("Introduce el nuevo título de la película:");
            String nuevoTitulo = scanner.nextLine();
            System.out.println("Introduce el nuevo director de la película:");
            String nuevoDirector = scanner.nextLine();
//hacemos el update con los nuevos datos y con el id antiguo.
            String sql = "UPDATE Pelicula SET titulo = ?, director = ? WHERE idPeli = ?";
            PreparedStatement pstmt = conexion.prepareStatement(sql);
            pstmt.setString(1, nuevoTitulo);
            pstmt.setString(2, nuevoDirector);
            pstmt.setString(3, id);

            //de nuevo para comprobar si ha funcionado, usamos las filas conectadas > 0.
            int filasAfectadas = pstmt.executeUpdate();
            if (filasAfectadas > 0) {
                System.out.println("Película modificada correctamente.");
            } else {
            	//Por si no hay ninguna pelicula con ese id, nos saltaria el else.
                System.out.println("No se encontró ninguna película con ese ID.");
            }
            pstmt.close();
            conexion.close();
        } catch (SQLException e) {
        	//cerramos y controlamos los errores.
            System.out.println("Error al modificar la película: " + e.getMessage());
        }
    }
}