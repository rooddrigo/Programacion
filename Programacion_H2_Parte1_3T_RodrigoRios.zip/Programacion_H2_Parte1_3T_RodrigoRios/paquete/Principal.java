package paquete;

// importamos java sql y java util para poder usar el scanner
import java.sql.*;
import java.util.*;

//Creamos la clase principal
public class Principal {
    public static void main(String[] args) {
        // Datos de conexión de mi base de datos "cine"
        String url = "jdbc:mysql://localhost:3306/cine";
        String usuario = "root";
        String contraseña = "curso"; 
        // Creamos la variable opción siendo un int para el usuario.
        Scanner scanner = new Scanner(System.in);
        int opcion;
//Usamos un do while para asi asegurarnos de que al menos se ejecute una vez el programa
        do {
        	
        	//Llamamos al método mostrar menu.
            mostrarMenu();
            try {
                System.out.print("Selecciona una opción: ");
                opcion = Integer.parseInt(scanner.nextLine());

                switch (opcion) {
                    case 1:
                        // Llamamos el método mostrar peliculas con los datos de acceso necesarios.
                        mostrarPeliculas(url, usuario, contraseña);
                        break;
                    case 2:
                    	// La opción dos es salirse.
                        System.out.println("¡Hasta luego!");
                        break;
                    default:
                    	// Controlamos que no funciona otra opción
                        System.out.println("Opción no válida. Intenta de nuevo.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Por favor, ingresa un número válido.");
                opcion = 0; // Repetimos el menú
            }

        } while (opcion != 2); // El bucle se repite hasta que el usuario seleccione "Salir"

        scanner.close(); // Cerramos el escáner
    }
    //Método de mostrar menu con las dos opciones
    public static void mostrarMenu() {
        System.out.println("\n----- MENÚ -----");
        System.out.println("1 - Ver películas");
        System.out.println("2 - Salir");
    }

    public static void mostrarPeliculas(String url, String usuario, String contraseña) {
        try {
            // Establecemos la conexión con la base de datos
            Connection conexion = DriverManager.getConnection(url, usuario, contraseña);
            Statement stmt = conexion.createStatement();
            
            // Consulta SQL para obtener todas las películas con sus géneros haciendo un join.
            String consultaPeliculas = "SELECT p.idPeli, p.titulo, p.director, p.duracion, p.clasificacion, p.idiomaOriginal, g.nombreGenero " +
                                       "FROM Pelicula p " +
                                       "JOIN Pelicula_Genero pg ON p.idPeli = pg.idPeli " +
                                       "JOIN Genero g ON pg.idGenero = g.idGenero";
            
            ResultSet rs = stmt.executeQuery(consultaPeliculas);
            System.out.println("\nCartelera\n");

            // Mostramos los resultados con un while los resultados
            while (rs.next()) {
                System.out.println("ID: " + rs.getString("idPeli"));
                System.out.println("Título: " + rs.getString("titulo"));
                System.out.println("Director: " + rs.getString("director"));
                System.out.println("Duración: " + rs.getInt("duracion") + " minutos");
                System.out.println("Clasificación de edad: " + rs.getString("clasificacion"));
                System.out.println("Idioma original: " + rs.getString("idiomaOriginal"));
                System.out.println("Genero: " + rs.getString("nombreGenero"));
                System.out.println("\n");
            }
            // Cerramos el rs y el catch para las excepciones
            rs.close();
        } catch (SQLException e) {
        	  System.out.println("Error: " + e.getMessage());
        }
    }
}
