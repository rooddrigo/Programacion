import misClases.Verificador;

public class VerificadorPrincipal {
    public static void main(String[] args) {
        Verificador numero = new Verificador();
        System.out.println(numero.esMayorYPar(8));
        System.out.println(numero.esMayorYPar(7));
        System.out.println(numero.esMayorYPar(16));
    }
}
