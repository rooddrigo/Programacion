package misClases;
public class AreaCuadrado {
    public float calcularArea(int lado) {
        float area = lado * lado;
        return area; 
}
}
