package misClases;
public class MostrarMensaje {
    public void saludar() {
	String saludar = "Hola, Bienvenido a Java";
System.out.println(saludar);
    }
}