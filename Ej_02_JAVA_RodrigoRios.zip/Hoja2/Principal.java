import misClases.AreaCuadrado;
public class Principal{
public static void main(String[] args){
AreaCuadrado resultado = new AreaCuadrado();
	float area = resultado.calcularArea(4);
	System.out.println("El área es: " + area);
}
}