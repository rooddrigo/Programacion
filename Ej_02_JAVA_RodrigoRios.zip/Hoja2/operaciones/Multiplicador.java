package operaciones;
public class Multiplicador{
public float multiplicar(int a, int b){
	float resultado = a * b;
	return resultado;
}
}
