import misClases.MostrarMensaje;
public class Saludo {
    public static void main(String[] args) {
        MostrarMensaje mensaje = new MostrarMensaje(); 
        mensaje.saludar();
    }
}

