import misClases.OperacionesBasicas;

public class OperacionesPrincipales {
    public static void main(String[] args) {
        System.out.println(OperacionesBasicas.sumar(4, 2));
        System.out.println(OperacionesBasicas.restar(4, 2));
        System.out.println(OperacionesBasicas.multiplicar(4, 2));
        System.out.println(OperacionesBasicas.dividir(4, 2));
    }
}
