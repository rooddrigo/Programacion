import misClases.Circunferencia;

public class CircunferenciaPrincipal {
    public static void main(String[] args) {
        Circunferencia circulo = new Circunferencia();
        System.out.println(circulo.calcularCircunferencia(5));
        System.out.println(circulo.calcularCircunferencia(10));
        System.out.println(circulo.calcularCircunferencia(15));
    }
}
