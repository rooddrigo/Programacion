import misClases.Comparador;

public class ComparadorPrincipal {
    public static void main(String[] args) {
        Comparador comparador = new Comparador();
        comparador.compararNumeros(5, 10);
        comparador.compararNumeros(10, 10);
        comparador.compararNumeros(15, 10);
}
}