import misClases.Conversor;

public class ConversorPrincipal {
    public static void main(String[] args) {
        Conversor numero = new Conversor();
        System.out.println(numero.convertirDoubleAInt(8.9));
        System.out.println(numero.convertirDoubleAInt(7.3));
        System.out.println(numero.convertirDoubleAInt(16.6));
    }
}
