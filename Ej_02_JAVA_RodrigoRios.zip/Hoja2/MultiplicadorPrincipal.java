import operaciones.Multiplicador;
public class MultiplicadorPrincipal{
    public static void main (String[] args){
	Multiplicador total = new Multiplicador();
	float resultado = total.multiplicar(4,8);
	System.out.println("El resultado del producto es :" + resultado);
}
}