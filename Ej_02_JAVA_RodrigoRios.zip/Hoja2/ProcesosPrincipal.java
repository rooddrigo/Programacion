import misClases.Proceso;
public class ProcesosPrincipal {
    public static void main(String[] args) {
        Proceso proceso = new Proceso();
        proceso.pasoDos();
    }
}
