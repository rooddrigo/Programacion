package paquetes;

public interface Saludable {
    void realizarChequeo();
}
class Persona implements Saludable {
    @Override
    public void realizarChequeo() {
        System.out.println("Realizando chequeo médico...");
    }
}