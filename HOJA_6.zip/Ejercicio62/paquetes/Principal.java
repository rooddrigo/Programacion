package paquetes;

public class Principal {
    public static void main(String[] args) {
        Factura factura = new Factura();
        factura.imprimir();
    }
}