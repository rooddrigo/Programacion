package paquetes;

public interface Imprimible {
	void imprimir();
}
