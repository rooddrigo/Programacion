package paquetes;

public class Principal {
    public static void main(String[] args) {
        Cuadrado cuadrado = new Cuadrado(2);
        Triangulo triangulo = new Triangulo(4, 3);

        System.out.println("Área del cuadrado: " + cuadrado.calcularArea());
        System.out.println("Área del triángulo: " + triangulo.calcularArea());
    }
}