package paquetes;

public interface Figura {
	double calcularArea();
}
