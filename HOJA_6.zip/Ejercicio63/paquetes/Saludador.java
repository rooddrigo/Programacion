package paquetes;

public interface Saludador {
	void saludar();
}
