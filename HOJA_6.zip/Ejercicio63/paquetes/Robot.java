package paquetes;

public class Robot implements Saludador {
    @Override
    public void saludar() {
        System.out.println("Hola, soy un robot.");
    }
}
