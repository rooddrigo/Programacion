package paquetes;

public class Principal {
	 public static void main(String[] args) {
	        CorreoElectronico correo = new CorreoElectronico();
	        correo.enviarNotificacion();
	        
	        MensajeTexto mensaje = new MensajeTexto();
	        mensaje.enviarNotificacion();
	    }
	}

