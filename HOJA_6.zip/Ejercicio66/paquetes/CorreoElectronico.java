package paquetes;

public class CorreoElectronico implements Notificable {
    @Override
    public void enviarNotificacion() {
        System.out.println("Enviando notificación por correo");
    }
}
