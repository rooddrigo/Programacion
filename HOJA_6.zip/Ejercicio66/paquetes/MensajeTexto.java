package paquetes;

public class MensajeTexto implements Notificable {
    @Override
    public void enviarNotificacion() {
        System.out.println("Enviando notificación por mensaje");
    }
}
