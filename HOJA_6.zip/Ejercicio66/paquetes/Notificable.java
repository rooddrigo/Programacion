package paquetes;

public interface Notificable {
	void enviarNotificacion();

}
