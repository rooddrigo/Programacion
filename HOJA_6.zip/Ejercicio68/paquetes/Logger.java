package paquetes;

public interface Logger {
	void registrar(String Mensaje);
	void separador();
}
