package paquetes;

public class ConsolaLogger implements Logger {

    @Override
    public void registrar(String mensaje) {
        System.out.println("Registro: " + mensaje);
    }
    @Override
    public void separador() {
        System.out.println("--------------");
    }
}
