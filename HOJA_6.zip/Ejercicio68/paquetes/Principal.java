package paquetes;

public class Principal {
	public static void main(String[] args) {
        ConsolaLogger logger = new ConsolaLogger();
        logger.registrar("hoolaaaaaaaa.");
        logger.separador();
        logger.registrar("holallalalall2.");
    }
}