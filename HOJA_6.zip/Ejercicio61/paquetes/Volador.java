package paquetes;

public interface Volador {
	    void volar();
	}