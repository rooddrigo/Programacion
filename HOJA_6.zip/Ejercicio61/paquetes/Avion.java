package paquetes;

class Avion implements Volador {
    @Override
    public void volar() {
        System.out.println("El avión está volando");
    }
}
