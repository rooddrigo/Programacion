package paquetes;

public class Principal {
    public static void main(String[] args) {
        
        Avion avion = new Avion();
        avion.volar();
        
        Pajaro pajaro = new Pajaro();
        pajaro.volar();
    }
}
