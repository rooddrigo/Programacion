package paquetes;

public class Artista implements Cantante, Bailarin {
    @Override
    public void cantar() {
        System.out.println("El artista está cantando.");
    }
    @Override
    public void bailar() {
        System.out.println("El artista está bailando.");
    }
}