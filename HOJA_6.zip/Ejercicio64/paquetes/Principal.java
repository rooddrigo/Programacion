package paquetes;

public class Principal {
	   public static void main(String[] args) {
	        Artista artista = new Artista();
	        artista.cantar();
	        artista.bailar();
	    }
	}
