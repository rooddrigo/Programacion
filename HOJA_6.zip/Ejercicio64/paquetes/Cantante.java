package paquetes;

public interface Cantante {
	void cantar();
}
