package paquetes;

public interface Bailarin {
	void bailar(); 
}
