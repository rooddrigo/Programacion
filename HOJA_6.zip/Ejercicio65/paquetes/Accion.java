package paquetes;

public interface Accion {
	void ejecutar();
}
