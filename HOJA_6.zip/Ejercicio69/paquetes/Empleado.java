package paquetes;

public class Empleado implements Identificable {
    private String nombre;
    private int id;
    public Empleado(String nombre, int id) {
        this.nombre = nombre;
        this.id = id;
    }
    @Override
    public void mostrarIdentidad() {
        System.out.println("Nombre: " + nombre);
        System.out.println("ID: " + id);
    }
}


