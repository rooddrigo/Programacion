package paquetes;

public class Principal {
	 public static void main(String[] args) {
	        Empleado empleado = new Empleado("Pepe Botella", 2000);
	        empleado.mostrarIdentidad();
	    }
	}
