package paquetes;

public interface Identificable {
	void mostrarIdentidad();
}
