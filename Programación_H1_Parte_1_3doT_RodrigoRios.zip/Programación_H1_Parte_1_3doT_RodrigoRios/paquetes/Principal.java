package paquetes;
//importamos java util para poder usar hashmap y scanner.
import java.util.*;

//Creamos la clase Principal que contendrá los métodos y el hashmap
public class Principal {

//Creamos el hashmap de que tendra el chip de los animales como clave para poder buscarlos o introducir nuevos.
 static HashMap<String, Animal> animales = new HashMap<>();

 //Para acceder a los chips, mediante el metodo darAltaAnimal, hacemos un get de los chips, si es null significará
 //que no hay animales con ese chip y podremos introducirlo, si no, nos saldrá el error.
 public static void darAltaAnimal(Animal animal) {
     if (animales.get(animal.getChip()) == null) {
         animales.put(animal.getChip(), animal);
         System.out.println("Animal registrado correctamente.");
     } else {
         System.out.println("Ese chip ya está registrado.");
     }
 }

 //creamos la funcion de buscar animal, en la cual mediante un chip que introducimos con un scanner, hará un get
 // si el resultado es distinto de null, habrá un animal con ese chip. Si no saltará el else.
 public static void buscarAnimal(String chip) {
     Animal animalBuscar = animales.get(chip);
     if (animalBuscar != null) {
         animalBuscar.mostrar();
     } else {
         System.out.println("Animal no encontrado.");
     }
 }

 //en el main, hacemos un scanner para la busqueda por chip
 public static void main(String[] args) {
     Scanner sc = new Scanner(System.in);
     //introducimos animales para probar que no se puedan duplicar
     darAltaAnimal(new Perro("P1", "Perro1", 10, "raza de Perro1", false, "Grande"));
     darAltaAnimal(new Gato("G1", "Gato1", 2, "raza de gato1", true, true));
     darAltaAnimal(new Perro("P1", "Perro Duplicado", 3, "raza de perro duplicado", false, "Enano"));
     darAltaAnimal(new Gato("G1", "Gato Duplicado", 33, "raza de gato duplicado", false, false));
     //hacemos el scanner y comprobamos si existe ese chip
     System.out.print("Introduce el chip del animal que quieras buscar: ");
     String chip = sc.nextLine();
     buscarAnimal(chip);
     //cerramos el scanner
     sc.close();
 }
}
