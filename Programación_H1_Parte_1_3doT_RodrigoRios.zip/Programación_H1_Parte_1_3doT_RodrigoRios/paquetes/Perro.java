package paquetes;
public class Perro extends Animal {
    // Creamos el atributo adicional de tamaño para el perro, de tipo String y privado para que sea único
    private String tamaño;
    public Perro(String chip, String nombre, int edad, String raza, boolean adoptado, String tamaño) {
        // Llamamos al constructor de la clase Animal para inicializar los atributos.
        super(chip, nombre, edad, raza, adoptado);
        // Inicializamos el atributo de tamaño
        this.tamaño = tamaño;
    }
    // Sobrescribimos el método mostrar de la clase abstracta Animal por eso ponemos el override.
    @Override
    public void mostrar() {
        // Imprimimos la información del perro.
        System.out.println("Animal: Perro || Chip: " + chip + " || Nombre: " + nombre + " || Edad: " + edad + 
            " || Raza: " + raza + " || Adoptado: " + adoptado + " || Tamaño: " + tamaño);
    }
}
